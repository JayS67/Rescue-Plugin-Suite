<?php
if (!defined('ABSPATH')) exit;

final class StraySafe_UI_Suite_Plugin {
  const SNAP_KEY = 'straysafe_ui_suite_snapshots_v1';
  const LOG_KEY = 'straysafe_ui_suite_version_log_v1';
  const WIZARD_KEY = 'straysafe_ui_suite_needs_setup_v1';
  const OPT_KEY = 'straysafe_ui_suite_settings_v83';
  const USER_DEFAULTS_KEY = 'asm_plugin_suite_user_defaults_v1';
  const ANALYTICS_KEY = 'asm_plugin_suite_analytics_v1';

  public static function init() {
    self::include_modules();
    add_action('admin_init', [__CLASS__, 'ensure_defaults_loaded'], 5);
    add_action('admin_init', [__CLASS__, 'maybe_redirect_to_setup_wizard'], 20);
    add_action('admin_notices', [__CLASS__, 'render_admin_notices']);
    add_action('admin_menu', [__CLASS__, 'admin_menu'], 20);
    add_action('admin_menu', [__CLASS__, 'remove_legacy_admin_pages'], 999);
    add_action('wp', [__CLASS__, 'maybe_disable_cache_for_suite_pages']);
    add_action('admin_post_straysafe_ui_suite_save', [__CLASS__, 'handle_save']);
    add_action('admin_post_straysafe_ui_suite_preview', [__CLASS__, 'render_preview']);
    add_action('admin_post_straysafe_ui_suite_export', [__CLASS__, 'handle_export']);
    add_action('admin_post_straysafe_ui_suite_import', [__CLASS__, 'handle_import']);
    add_action('admin_post_straysafe_ui_suite_export_module', [__CLASS__, 'handle_export_module']);
    add_action('admin_post_straysafe_ui_suite_import_module', [__CLASS__, 'handle_import_module']);
    add_action('admin_post_straysafe_ui_suite_save_pack', [__CLASS__, 'handle_save_pack']);
    add_action('admin_post_straysafe_ui_suite_load_pack', [__CLASS__, 'handle_load_pack']);
    add_action('admin_post_straysafe_ui_suite_reset_defaults', [__CLASS__, 'handle_reset_defaults']);
    add_action('admin_post_straysafe_ui_suite_save_current_defaults', [__CLASS__, 'handle_save_current_defaults']);
    add_action('admin_post_straysafe_ui_suite_restore_snapshot', [__CLASS__, 'handle_restore_snapshot']);
    add_action('admin_post_straysafe_ui_suite_delete_snapshot', [__CLASS__, 'handle_delete_snapshot']);
    add_action('admin_post_straysafe_ui_suite_proxy_test', [__CLASS__, 'handle_proxy_test']);
    add_action('admin_post_straysafe_ui_suite_proxy_clear_cache', [__CLASS__, 'handle_proxy_clear_cache']);
    add_action('admin_post_straysafe_ui_suite_setup_save', [__CLASS__, 'handle_setup_save']);
    add_action('update_option_' . self::OPT_KEY, [__CLASS__, 'sync_legacy_options_from_db'], 10, 2);
    add_action('init', [__CLASS__, 'register_form_shortcodes'], 20);
    add_action('init', [__CLASS__, 'register_custom_ui_shortcodes'], 21);
    add_action('init', [__CLASS__, 'register_widget_shortcodes'], 22);
    add_action('init', [__CLASS__, 'register_quiz_shortcode'], 23);
    add_action('wp_ajax_asm_plugin_suite_track', [__CLASS__, 'handle_track_event']);
    add_action('wp_ajax_nopriv_asm_plugin_suite_track', [__CLASS__, 'handle_track_event']);
  }

  public static function activate() {
    $merged = self::merge_with_defaults(self::default_settings(), self::load_saved_settings());
    update_option(self::OPT_KEY, $merged, false);
    update_option(self::WIZARD_KEY, 1, false);
    self::record_version_event('activated');
    self::sync_legacy_options($merged);
    if (class_exists('StraySafe_UI_Suite_SEO')) StraySafe_UI_Suite_SEO::rewrite_rules();
    flush_rewrite_rules(false);
  }

  private static function include_modules() {
    self::define_proxy_constants_from_settings();
    require_once STRAYSAFE_SUITE_PATH . 'includes/modules/forms/class-module.php';
    require_once STRAYSAFE_SUITE_PATH . 'includes/modules/adoptables/class-module.php';
    require_once STRAYSAFE_SUITE_PATH . 'includes/modules/adopted/class-module.php';
    require_once STRAYSAFE_SUITE_PATH . 'includes/modules/statistics/class-module.php';
    require_once STRAYSAFE_SUITE_PATH . 'includes/modules/asm-proxy/class-module.php';
  }

  public static function default_settings() {
    $defaults = [
      'global' => [
        'style_behavior' => 'original_ui_defaults',
        'cache_adoptables_seconds' => 60,
        'cache_adopted_seconds' => 120,
        'cache_stats_seconds' => 60,
        'bypass_cache' => 0,
        'adoptables_page_url' => '',
        'adopted_page_url' => '',
        'brand_color' => '#401268',
        'background_color' => '#fcf5fd',
        'modal_divider_color' => '#d6d6d6',
        'text_primary_color' => '#374151',
        'text_muted_color' => '#6b7280',
        'paw_opacity' => '0.15',
        'paw_count' => 50,
        'font_family' => 'Roboto',
        'font_scale_percent' => 100,
        'adoptables_style_source' => 'auto',
        'adopted_style_source' => 'auto',
        'stats_style_source' => 'auto',
        'data_source' => 'asm',
        'custom_api_url' => '',
        'custom_api_key' => '',
        'custom_api_auth_header' => 'X-API-Key',
        'custom_api_adoptables_url' => '',
        'custom_api_adoptions_url' => '',
        'custom_api_report_url' => '',
        'custom_api_incare_url' => '',
        'custom_api_image_url' => '',
        'shelterluv_api_key' => '',
        'shelterluv_base_url' => 'https://www.shelterluv.com',
        'shelterluv_org_id' => '',
        'shelterluv_statuses' => 'adoptable,foster',
        'shelterluv_location_ids' => '',
        'shelterluv_animal_type' => 'cat',
        'petpoint_username' => '',
        'petpoint_password' => '',
        'petpoint_base_url' => '',
        'petpoint_shelter_id' => '',
        'petpoint_location_ids' => '',
        'petpoint_species_id' => '2',
        'petpoint_statuses' => 'available,foster',
        'petpoint_adopted_report_id' => '',
      ],
      'adoptables' => [
        'brand_color' => '#401268', 'background_color' => '#fcf5fd', 'paw_opacity' => '0.15', 'paw_count' => 50,
        'title_text' => 'Meet Our Adoptable Animals', 'subtitle_text' => 'Longest in our care are shown first',
        'footer_text' => 'Every adoption changes a life. Thank you for supporting rescue work. 🐾',
        'loading_status_text' => 'Loading adoptable animals...', 'loading_page_label_text' => 'Loading...',
        'tips_text' => 'Tip: Click the dark background (outside the card) or press ESC to close.', 'font_family' => 'Roboto',
        'cats_only' => 1, 'show_top_navigation' => 1, 'cols_mobile' => 2, 'rows_mobile' => 3, 'cols_tablet' => 2, 'rows_tablet' => 3,
        'cols_desktop' => 4, 'rows_desktop' => 2, 'gap_x_mobile' => 20, 'gap_y_mobile' => 20, 'gap_x_tablet' => 24,
        'gap_y_tablet' => 24, 'gap_x_desktop' => 24, 'gap_y_desktop' => 24, 'card_scale_mobile' => 100,
        'card_scale_tablet' => 100, 'card_scale_desktop' => 100, 'card_padding' => 12, 'card_radius' => 16,
        'modal_max_width' => 896, 'fs_heading_mobile' => 28, 'fs_heading_tablet' => 36, 'fs_heading_desktop' => 42,
        'fs_subheading_mobile' => 16, 'fs_subheading_tablet' => 18, 'fs_subheading_desktop' => 20,
        'fs_footer_mobile' => 14, 'fs_footer_tablet' => 16, 'fs_footer_desktop' => 16,
        'fs_page_label_mobile' => 13, 'fs_page_label_tablet' => 13, 'fs_page_label_desktop' => 13,
        'fs_modal_name_mobile' => 18, 'fs_modal_name_tablet' => 20, 'fs_modal_name_desktop' => 20,
        'fs_modal_meta_mobile' => 14, 'fs_modal_meta_tablet' => 14, 'fs_modal_meta_desktop' => 14,
        'fs_modal_desc_mobile' => 16, 'fs_modal_desc_tablet' => 18, 'fs_modal_desc_desktop' => 18,
        'fs_tips_mobile' => 12, 'fs_tips_tablet' => 12, 'fs_tips_desktop' => 12,
        'fw_heading' => 800, 'fw_subheading' => 600, 'fw_footer' => 500, 'fw_page_label' => 600,
        'fw_modal_name' => 800, 'fw_modal_meta' => 600, 'fw_modal_desc' => 400, 'fw_tips' => 600,
        'modal_divider_color' => '#d6d6d6', 'modal_divider_thickness' => 2, 'modal_divider_radius' => 999,
        'modal_global_text' => "If you think this kitty could be the perfect match for you, please complete the adoption application form located below our adoptable cats.\n\nWe do not rehome on a first-come, first-served basis; instead, we carefully match each of our precious cats and kittens with the most suitable homes. Therefore, if you see the enquiries active label, rest assured you can still apply! 🐾✨\n\nAll of our cats are rehomed vaccinated, flea and worm treated, microchipped, neutered (if old enough), and with 5 weeks free pet insurance provided by Agria.\n\nTo ensure every cat goes to the right home, all applicants will require a homecheck and as always, adoption fees apply. ✅\n\nWith love,\nStraySafe Rescue 🐾\n\nStray today. Safe tomorrow.",
        'show_reservation_label' => 1, 'show_pending_reservation_label' => 1, 'show_other_reservation_label' => 1, 'reservation_pending_label' => 'Pending Adoption', 'reservation_active_label' => 'Enquiries Active',
        'reservation_label_halign' => 'left', 'reservation_label_valign' => 'top',
        'card_border_enabled' => 1, 'card_border_color' => '#401268', 'card_border_weight' => 2,
        'enable_deep_links' => 1, 'share_button_text' => 'Share', 'share_copied_text' => 'Link copied',
        'enable_apply_button' => 1, 'apply_button_text' => 'Apply', 'apply_form_shortcode' => 'adoption_form',
        'apply_button_bg_color' => '#401268', 'apply_button_text_color' => '#ffffff', 'apply_button_border_color' => '#401268', 'apply_button_radius' => 16,
        'modal_contact_url' => '',
        'custom_button_1_enabled' => 0, 'custom_button_1_text' => '', 'custom_button_1_url' => '', 'custom_button_1_new_tab' => 0, 'custom_button_1_style' => 'primary',
        'custom_button_2_enabled' => 0, 'custom_button_2_text' => '', 'custom_button_2_url' => '', 'custom_button_2_new_tab' => 0, 'custom_button_2_style' => 'secondary',
        'custom_button_3_enabled' => 0, 'custom_button_3_text' => '', 'custom_button_3_url' => '', 'custom_button_3_new_tab' => 0, 'custom_button_3_style' => 'outline',
        'enable_filters' => 1, 'enable_filter_age' => 1, 'enable_filter_sex' => 1, 'enable_filter_breed' => 1, 'enable_exclude_pending_filter' => 1,
        'filter_age_label' => 'Age', 'filter_sex_label' => 'Sex', 'filter_breed_label' => 'Breed', 'filter_exclude_pending_label' => 'Hide animals pending adoption',
        'fallback_description' => 'More information about this animal will be added soon. Please contact the rescue for details.',
        'detect_bonded_from_description' => 1, 'bonded_label_text' => 'Bonded Pair', 'bonded_label_bg_color' => '#ec4899', 'bonded_label_text_color' => '#ffffff',
        'detect_indoor_only_from_description' => 1, 'indoor_only_label_text' => 'Indoor Only', 'indoor_only_label_bg_color' => '#0f766e', 'indoor_only_label_text_color' => '#ffffff',
        'enable_modal_slideshow_controls' => 1,
        'enable_favourites' => 1, 'favourites_label_text' => 'Favourites', 'show_only_favourites_label' => 'Show favourites only', 'favourite_button_position' => 'top_left',
        'enable_compare_tool' => 1, 'compare_button_text' => 'Compare favourites', 'favourites_modal_title' => 'Saved favourites', 'compare_modal_title' => 'Compare favourites',
        'enable_modals' => 1,
        'display_style' => 'classic',
        'builder_card_order' => "image\nreservation_badge\nname_meta\nbreed_line\nfavourite_button",
        'builder_modal_order' => "gallery\nbadges\ninfo_cards\ntips\ndescription\nglobal_text\ncontact_footer\ncustom_buttons",
        'builder_header_actions' => "apply\nfavourite\nshare\nclose",
      ],
      'adopted' => [
        'brand_color' => '#401268', 'background_color' => '#fcf5fd', 'text_primary_color' => '#374151', 'text_muted_color' => '#6b7280',
        'paw_opacity' => '0.15', 'paw_count' => 50, 'title_text' => 'Found My Furever Home',
        'subtitle_text' => 'Recently adopted cats - the newest happy endings first',
        'footer_text' => 'Want to be part of the next happy ending? Consider adopting or fostering 🐾',
        'font_family' => '', 'min_year' => 2025, 'show_top_navigation' => 1, 'cols_mobile' => 2, 'rows_mobile' => 3, 'cols_tablet' => 3, 'rows_tablet' => 3,
        'cols_desktop' => 4, 'rows_desktop' => 2, 'card_scale_mobile' => 100, 'card_scale_tablet' => 100, 'card_scale_desktop' => 100,
        'card_radius' => 16, 'card_padding' => 12, 'button_radius' => 16,
        'card_border_enabled' => 1, 'card_border_color' => '#401268', 'card_border_weight' => 2, 'date_label_halign' => 'right', 'date_label_valign' => 'top',
        'fs_heading_mobile' => 30, 'fs_heading_tablet' => 36, 'fs_heading_desktop' => 42,
        'fs_subheading_mobile' => 16, 'fs_subheading_tablet' => 18, 'fs_subheading_desktop' => 20,
        'fs_footer_mobile' => 14, 'fs_footer_tablet' => 16, 'fs_footer_desktop' => 16,
        'fs_page_label_mobile' => 13, 'fs_page_label_tablet' => 13, 'fs_page_label_desktop' => 13,
        'fs_card_name_mobile' => 13, 'fs_card_name_tablet' => 16, 'fs_card_name_desktop' => 18,
        'fs_card_meta_mobile' => 11, 'fs_card_meta_tablet' => 14, 'fs_card_meta_desktop' => 14,
        'fs_badge_mobile' => 10, 'fs_badge_tablet' => 12, 'fs_badge_desktop' => 16,
        'fw_heading' => 800, 'fw_subheading' => 600, 'fw_footer' => 500, 'fw_page_label' => 600,
        'fw_card_name' => 800, 'fw_card_meta' => 600, 'fw_badge' => 800,
        'enable_modals' => 1, 'enable_deep_links' => 1, 'share_button_text' => 'Share', 'share_copied_text' => 'Link copied',
        'modal_global_text' => 'Every adoption changes a life. Thank you for supporting rescue work. 🐾',
        'adoptables_cta_enabled' => 0,
        'adoptables_cta_text' => 'Looking for your next best friend?',
        'adoptables_cta_button_text' => 'View animals for adoption',
        'adoptables_cta_url' => '',
      ],
      'stats' => [
        'brand_color' => '#401268', 'background_color' => '#fcf5fd', 'min_year' => 2026, 'paw_opacity' => '0.15', 'paw_count' => 50,
        'title_text' => 'Our Rescue Impact', 'year_label_prefix' => "This Year's Statistics -",
        'footer_text' => 'Every number represents a life changed. Thank you for supporting rescue work. 🐾', 'font_family' => '',
        'card_radius' => 16, 'card_padding' => 24, 'card_border_enabled' => 1, 'card_border_color' => '#401268', 'card_border_weight' => 2, 'layout_mode' => 'one_row', 'cols_mobile' => 2, 'rows_mobile' => 3,
        'cols_tablet' => 2, 'rows_tablet' => 3, 'cols_desktop' => 6, 'rows_desktop' => 1,
        'fs_heading_mobile' => 28, 'fs_heading_tablet' => 36, 'fs_heading_desktop' => 42,
        'fs_subheading_mobile' => 16, 'fs_subheading_tablet' => 18, 'fs_subheading_desktop' => 20,
        'fs_paragraph_mobile' => 14, 'fs_paragraph_tablet' => 16, 'fs_paragraph_desktop' => 16,
        'card_w_mobile' => 0, 'card_w_tablet' => 0, 'card_w_desktop' => 0, 'card_h_mobile' => 0, 'card_h_tablet' => 0, 'card_h_desktop' => 0,
        'label_brought' => 'Brought In', 'caption_brought' => 'Found their way to us', 'icon_brought' => 'heart',
        'label_adopted' => 'Adopted', 'caption_adopted' => 'Furever homes found', 'icon_adopted' => 'home',
        'label_vaccinated' => 'Vaccinated', 'caption_vaccinated' => 'Protected & healthy', 'icon_vaccinated' => 'syringe',
        'label_neutered' => 'Neutered', 'caption_neutered' => 'Spay & neuter care', 'icon_neutered' => 'stethoscope',
        'label_chipped' => 'Microchipped', 'caption_chipped' => 'Always traceable', 'icon_chipped' => 'map_pin',
        'label_in_care' => 'In Our Care', 'caption_in_care' => 'Currently safe with us', 'icon_in_care' => 'shield',
        'card_order' => "brought\nadopted\nvaccinated\nneutered\nchipped\nin_care",
      ],
      'shortcodes' => ['adoptables' => 'adoptables', 'adopted' => 'adopted', 'statistics' => 'stats'],
      'widgets' => [
        'featured_shortcode' => 'featured_animal',
        'featured_enabled' => 1,
        'featured_mode' => 'random',
        'featured_manual_id' => '',
        'featured_title_text' => 'Featured animal',
        'featured_subtitle_text' => 'Meet one of the animals looking for a home',
        'featured_button_text' => 'View animal',
        'stories_shortcode' => 'adoption_stories',
        'stories_enabled' => 1,
        'stories_title_text' => 'Adoption stories',
        'stories_count' => 6,
        'stories_year_mode' => 'current'
      ],
      'quiz' => [
        'quiz_shortcode' => 'adoption_match_quiz',
        'quiz_enabled' => 1,
        'quiz_title_text' => 'Find your match',
        'quiz_intro_text' => 'Answer a few quick questions and we will suggest adoptable animals that may suit your home.',
        'q1_text' => 'What age would you prefer?',
        'q1_kitten_label' => 'Under 1 year',
        'q1_adult_label' => '1 to 3 years',
        'q1_senior_label' => '5+ years',
        'q1_either_label' => 'No preference',
        'q2_text' => 'Do you have a preference for sex?',
        'q2_female_label' => 'Female',
        'q2_male_label' => 'Male',
        'q2_either_label' => 'No preference',
        'q3_text' => 'Would you prefer an indoor-only cat?',
        'q3_yes_label' => 'Yes',
        'q3_no_label' => 'No preference',
        'q3_hide' => 0,
        'results_title_text' => 'Suggested matches',
        'results_empty_text' => 'No exact matches were found. Please browse all adoptables instead.',
        'age_categories' => "Under 1 year|0|1\n1 to 3 years|1|3\n3 to 5 years|3|5\n5+ years|5|"
      ],
      'forms' => [
        'account' => 'straysafe',
        'items' => [
          ['shortcode' => 'adoption_form', 'form_id' => '59'],
          ['shortcode' => 'volunteer_form', 'form_id' => '104'],
          ['shortcode' => 'waiting_list_form', 'form_id' => '106'],
          ['shortcode' => 'lost_cat_form', 'form_id' => '51'],
        ],
      ],
      'proxy' => [
        'base_url' => 'https://service.sheltermanager.com/asmservice',
        'account' => '',
        'username' => '',
        'password' => '',
        'cache_adoptables_seconds' => 60,
        'cache_reports_seconds' => 60,
        'cache_incare_seconds' => 60,
        'cache_adoptions_seconds' => 300,
      ],
    ];
    $saved_defaults = get_option(self::USER_DEFAULTS_KEY, []);
    if (is_array($saved_defaults) && !empty($saved_defaults)) {
      $defaults = self::merge_with_defaults($defaults, $saved_defaults);
    }
    return $defaults;
  }

  private static function candidate_option_keys() {
    return [self::OPT_KEY];
  }

  private static function load_saved_settings() {
    foreach (self::candidate_option_keys() as $key) {
      $value = get_option($key, null);
      if (is_array($value) && !empty($value)) return $value;
    }
    return [];
  }

  private static function merge_with_defaults($defaults, $saved) {
    if (!is_array($defaults)) return $saved;
    $merged = $defaults;
    if (!is_array($saved)) return $merged;
    foreach ($defaults as $key => $default_value) {
      if (!array_key_exists($key, $saved)) continue;
      $saved_value = $saved[$key];
      if (is_array($default_value)) {
        $merged[$key] = self::merge_with_defaults($default_value, is_array($saved_value) ? $saved_value : []);
        continue;
      }
      if ($saved_value === null) continue;
      if (is_string($saved_value) && trim($saved_value) === '' && !(is_string($default_value) && $default_value === '')) continue;
      $merged[$key] = $saved_value;
    }
    return $merged;
  }

  public static function ensure_defaults_loaded() {
    if (!current_user_can('manage_options')) return;
    $defaults = self::default_settings();
    $saved = self::load_saved_settings();
    $merged = self::merge_with_defaults($defaults, $saved);
    if ($saved !== $merged) update_option(self::OPT_KEY, $merged, false);
    self::sync_legacy_options($merged);
  }

  public static function get_settings() {
    return self::merge_with_defaults(self::default_settings(), self::load_saved_settings());
  }

  private static function sanitize_shortcode_tag($value) {
    $value = strtolower((string)$value);
    $value = preg_replace('/[^a-z0-9_\-]/', '', $value);
    return trim($value, '_-');
  }

  private static function default_forms_items() { return self::default_settings()['forms']['items']; }

  public static function get_forms() {
    $settings = self::get_settings();
    $items = isset($settings['forms']['items']) && is_array($settings['forms']['items']) ? $settings['forms']['items'] : [];
    $forms = [];
    foreach ($items as $item) {
      $shortcode = self::sanitize_shortcode_tag($item['shortcode'] ?? '');
      $form_id = preg_replace('/[^0-9]/', '', (string)($item['form_id'] ?? ''));
      if ($shortcode && $form_id) $forms[$shortcode] = $form_id;
    }
    return $forms;
  }

  public static function register_form_shortcodes() {
    foreach (self::get_forms() as $shortcode => $form_id) {
      add_shortcode($shortcode, function() use ($form_id) { return StraySafe_UI_Suite_Plugin::render_form_shortcode($form_id); });
    }
  }

  public static function render_form_shortcode($form_id) {
    $settings = self::get_settings();
    $account = sanitize_text_field($settings['forms']['account'] ?? 'straysafe');
    $form_id = preg_replace('/[^0-9]/', '', (string)$form_id);
    if (!$account || !$form_id) return '<p>Form could not be loaded.</p>';
    $script_url = esc_url('https://service.sheltermanager.com/asmservice?account=' . rawurlencode($account) . '&method=online_form_js&formid=' . rawurlencode($form_id));
    ob_start(); ?>
    <section class="straysafe-form-wrap" aria-label="Online application form"><noscript><p>This application form requires JavaScript. Please contact StraySafe Rescue if you need help applying.</p></noscript><div id="asm3-onlineform" aria-live="polite"></div><script type="text/javascript" src="<?php echo esc_url($script_url); ?>"></script></section>
    <?php return ob_get_clean();
  }

  public static function register_custom_ui_shortcodes() {
    $settings = self::get_settings();
    $map = $settings['shortcodes'] ?? [];
    $a = self::sanitize_shortcode_tag($map['adoptables'] ?? 'adoptables');
    $b = self::sanitize_shortcode_tag($map['adopted'] ?? 'adopted');
    $c = self::sanitize_shortcode_tag($map['statistics'] ?? 'stats');
    if ($a && class_exists('StraySafe_Adoptables_UI_Shortcode') && $a !== StraySafe_Adoptables_UI_Shortcode::SHORTCODE) add_shortcode($a, ['StraySafe_Adoptables_UI_Shortcode', 'render_shortcode']);
    if ($b && class_exists('StraySafe_Adopted_UI_Shortcode') && $b !== StraySafe_Adopted_UI_Shortcode::SHORTCODE) add_shortcode($b, ['StraySafe_Adopted_UI_Shortcode', 'render_shortcode']);
    if ($c && $c !== 'stats') add_shortcode($c, function(){ return do_shortcode('[stats]'); });
  }

  public static function register_widget_shortcodes() {
    $settings = self::get_settings();
    $featured = self::sanitize_shortcode_tag($settings['widgets']['featured_shortcode'] ?? 'featured_animal');
    $stories = self::sanitize_shortcode_tag($settings['widgets']['stories_shortcode'] ?? 'adoption_stories');
    if ($featured) add_shortcode($featured, [__CLASS__, 'render_featured_shortcode']);
    if ($stories) add_shortcode($stories, [__CLASS__, 'render_stories_shortcode']);
  }

  public static function register_quiz_shortcode() {
    $settings = self::get_settings();
    $tag = self::sanitize_shortcode_tag($settings['quiz']['quiz_shortcode'] ?? 'adoption_match_quiz');
    if ($tag) add_shortcode($tag, [__CLASS__, 'render_quiz_shortcode']);
  }

  public static function render_quiz_shortcode($atts = []) {
    $settings = self::get_settings();
    $q = $settings['quiz'] ?? [];
    if (empty($q['quiz_enabled'])) return '';
    $adoptables_page_url = esc_url_raw($settings['global']['adoptables_page_url'] ?? '');
    ob_start(); ?>
    <section class="asm-adoption-quiz-widget" aria-labelledby="asm-quiz-title" style="--asm-quiz-brand:<?php echo esc_attr($settings['adoptables']['brand_color'] ?? '#401268'); ?>; --asm-quiz-bg:<?php echo esc_attr($settings['adoptables']['background_color'] ?? '#fcf5fd'); ?>; background:var(--asm-quiz-bg); border:none; border-radius:24px; padding:20px; box-shadow:0 12px 28px rgba(15,23,42,.08);">
      <h2 id="asm-quiz-title" style="margin:0;color:var(--asm-quiz-brand);font-size:2rem;line-height:1.15;"><?php echo esc_html($q['quiz_title_text'] ?? 'Find your match'); ?></h2>
      <p style="margin:.5rem 0 1.25rem;color:#6b7280;"><?php echo esc_html($q['quiz_intro_text'] ?? 'Answer a few quick questions and we will suggest adoptable animals that may suit your home.'); ?></p>
      <form id="asm-quiz-questions" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;align-items:end;">
        <label style="display:block;"><span style="display:block;font-weight:700;color:#374151;margin-bottom:.35rem;"><?php echo esc_html($q['q1_text'] ?? 'What age would you prefer?'); ?></span><select id="asm-quiz-age" style="width:100%;padding:10px 12px;border-radius:14px;border:1px solid #d1d5db;"><option value="either"><?php echo esc_html($q['q1_either_label'] ?? 'No preference'); ?></option><option value="Under 1 year">Under 1 year</option><option value="1 to 3 years">1 to 3 years</option><option value="3 to 5 years">3 to 5 years</option><option value="5+ years">5+ years</option></select></label>
        <label style="display:block;"><span style="display:block;font-weight:700;color:#374151;margin-bottom:.35rem;"><?php echo esc_html($q['q2_text'] ?? 'Do you have a preference for sex?'); ?></span><select id="asm-quiz-sex" style="width:100%;padding:10px 12px;border-radius:14px;border:1px solid #d1d5db;"><option value="either"><?php echo esc_html($q['q2_either_label'] ?? 'No preference'); ?></option><option value="Female"><?php echo esc_html($q['q2_female_label'] ?? 'Female'); ?></option><option value="Male"><?php echo esc_html($q['q2_male_label'] ?? 'Male'); ?></option></select></label>
        <?php if (empty($q['q3_hide'])): ?>
        <label style="display:block;"><span style="display:block;font-weight:700;color:#374151;margin-bottom:.35rem;"><?php echo esc_html($q['q3_text'] ?? 'Would you prefer an indoor-only cat?'); ?></span><select id="asm-quiz-indoor" style="width:100%;padding:10px 12px;border-radius:14px;border:1px solid #d1d5db;"><option value="either"><?php echo esc_html($q['q3_no_label'] ?? 'No preference'); ?></option><option value="yes"><?php echo esc_html($q['q3_yes_label'] ?? 'Yes'); ?></option><option value="no">No</option></select></label>
        <?php endif; ?>
        <label style="display:block;"><span style="display:block;font-weight:700;color:#374151;margin-bottom:.35rem;">Bonded pair</span><select id="asm-quiz-bonded" style="width:100%;padding:10px 12px;border-radius:14px;border:1px solid #d1d5db;"><option value="either">No preference</option><option value="yes">Yes</option><option value="no">No</option></select></label>
        <label style="display:block;"><span style="display:block;font-weight:700;color:#374151;margin-bottom:.35rem;">Good with cats</span><select id="asm-quiz-good-cats" style="width:100%;padding:10px 12px;border-radius:14px;border:1px solid #d1d5db;"><option value="either">No preference</option><option value="Yes">Yes</option><option value="No">No</option><option value="Unknown">Unknown</option><option value="Selective">Selective</option></select></label>
        <label style="display:block;"><span style="display:block;font-weight:700;color:#374151;margin-bottom:.35rem;">Good with dogs</span><select id="asm-quiz-good-dogs" style="width:100%;padding:10px 12px;border-radius:14px;border:1px solid #d1d5db;"><option value="either">No preference</option><option value="Yes">Yes</option><option value="No">No</option><option value="Unknown">Unknown</option><option value="Selective">Selective</option></select></label>
        <label style="display:block;"><span style="display:block;font-weight:700;color:#374151;margin-bottom:.35rem;">Good with children</span><select id="asm-quiz-good-children" style="width:100%;padding:10px 12px;border-radius:14px;border:1px solid #d1d5db;"><option value="either">No preference</option><option value="Yes">Yes</option><option value="No">No</option><option value="Unknown">Unknown</option><option value="Over 5">Over 5</option><option value="Over 12">Over 12</option></select></label>
        <div><button id="asm-quiz-run" type="button" style="display:inline-flex;align-items:center;justify-content:center;padding:12px 18px;border-radius:999px;background:var(--asm-quiz-brand);color:#fff;border:none;font-weight:700;cursor:pointer;">Show matches</button></div>
      </form>
      <div style="margin-top:1.25rem;"><h3 style="margin:0 0 .75rem;color:#111827;font-size:1.25rem;"><?php echo esc_html($q['results_title_text'] ?? 'Suggested matches'); ?></h3><div id="asm-quiz-results" role="status" aria-live="polite" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;"></div></div>
    </section>
    <script>(function(){
	      const root=document.currentScript.previousElementSibling; if(!root) return;
	      const endpoint=<?php echo wp_json_encode(rest_url('straysafe/v1/adoptables')); ?>;
	      const adoptablesPageUrl=<?php echo wp_json_encode($adoptables_page_url); ?>;
	      let animals=[];
	      function safe(v){ return String(v ?? '').trim(); }
	      function escHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
	      function escAttr(s){ return escHtml(s).replace(/"/g,String.fromCharCode(38,113,117,111,116,59)).replace(/'/g,String.fromCharCode(38,35,48,51,57,59)); }
	      function slugifyPart(value){ return String(value || '').toLowerCase().replace(/&/g,' and ').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').replace(/-{2,}/g,'-'); }
	      function catModalSlug(a){ const id=String(a.ID ?? a.ANIMALID ?? a.AnimalID ?? '').replace(/\D+/g,''); const name=slugifyPart(a.ANIMALNAME ?? a.AnimalName ?? ''); const code=slugifyPart(a.CODE ?? a.SHELTERCODE ?? a.ShelterCode ?? ''); return [name, code].filter(Boolean).join('-') || id; }
	      function modalLink(a){ const href=adoptablesPageUrl || window.location.href; try { const url=new URL(href, window.location.origin); url.searchParams.set('cat', catModalSlug(a)); return url.toString(); } catch(e) { const sep=String(href).includes('?') ? '&' : '?'; return String(href) + sep + 'cat=' + encodeURIComponent(catModalSlug(a)); } }
	      function descText(a){ return safe(a.ANIMALCOMMENTS ?? a.WEBSITEMEDIANOTES ?? a.DESCRIPTION ?? a.ANIMALDESCRIPTION).toLowerCase(); }
      function sexValue(a){ const raw=safe(a.SEXNAME ?? a.SexName ?? a.SEX); if(/^f/i.test(raw) || raw==='0') return 'Female'; if(/^m/i.test(raw) || raw==='1') return 'Male'; return raw; }
      function ageMonths(a){
        const direct=Number(a.AGE_MONTHS ?? a.age_months ?? a.AgeMonths);
        if (Number.isFinite(direct) && direct >= 0) return direct;
        const age=safe(a.ANIMALAGE ?? a.AnimalAge).toLowerCase(); if(!age) return null;
        let total=0, matched=false;
        const y=age.match(/(\d+(?:\.\d+)?)\s*year/); const m=age.match(/(\d+(?:\.\d+)?)\s*month/); const w=age.match(/(\d+(?:\.\d+)?)\s*week/);
        if(y){ total += parseFloat(y[1]) * 12; matched=true; }
        if(m){ total += parseFloat(m[1]); matched=true; }
        if(w){ total += parseFloat(w[1]) / 4.345; matched=true; }
        return matched ? Math.max(0, Math.round(total)) : null;
      }
      function ageBand(a){
        const band=safe(a.AGE_BAND ?? a.age_band ?? a.AgeBand); if (band) return band;
        const months=ageMonths(a); if (months===null) return '';
        if (months < 12) return 'Under 1 year';
        if (months < 36) return '1 to 3 years';
        if (months < 60) return '3 to 5 years';
        return '5+ years';
      }
      function hasIndoor(a){ return /\bindoor\b/i.test(descText(a)); }
      function hasBonded(a){ return /bonded with/i.test(descText(a)); }
      function normaliseChoice(v, allowed){ const raw=safe(v); if (!raw) return 'Unknown'; const hit=allowed.find(x => x.toLowerCase()===raw.toLowerCase()); return hit || raw; }
      function pickVal(a, keys){ for (const key of keys){ const val = a?.[key]; if (val !== undefined && val !== null && safe(val) !== '') return safe(val); } return ''; }
      function goodWithCats(a){ return normaliseChoice(pickVal(a,['ISGOODWITHCATSNAME','GoodWithCatsName','good_with_cats_name','GOODWITHCATSNAME','GOODWITHCATS','GoodWithCats','good_with_cats','GOOD_WITH_CATS']), ['Yes','No','Unknown','Selective']); }
      function goodWithDogs(a){ return normaliseChoice(pickVal(a,['ISGOODWITHDOGSNAME','GoodWithDogsName','good_with_dogs_name','GOODWITHDOGSNAME','GOODWITHDOGS','GoodWithDogs','good_with_dogs','GOOD_WITH_DOGS']), ['Yes','No','Unknown','Selective']); }
      function goodWithChildren(a){ return normaliseChoice(pickVal(a,['ISGOODWITHCHILDRENNAME','GoodWithChildrenName','good_with_children_name','GOODWITHCHILDRENNAME','GOODWITHCHILDREN','GoodWithChildren','good_with_children','GOOD_WITH_CHILDREN']), ['Yes','No','Unknown','Over 5','Over 12']); }
      function hasPending(a){ return String(a.primary_reservation_status ?? '').toLowerCase()==='pending adoption'; }
      function img(a){ const id=String(a.ID ?? a.ANIMALID ?? a.AnimalID ?? ''); return <?php echo wp_json_encode(rest_url('straysafe/v1/animal-image')); ?> + '?animalid=' + encodeURIComponent(id) + '&seq=1'; }
	      function matchesAll(a,opts){ return (opts.age==='either' || ageBand(a)===opts.age) && (opts.sex==='either' || sexValue(a)===opts.sex) && (opts.indoor==='either' || (opts.indoor==='yes' ? hasIndoor(a) : !hasIndoor(a))) && (opts.bonded==='either' || (opts.bonded==='yes' ? hasBonded(a) : !hasBonded(a))) && (opts.goodCats==='either' || goodWithCats(a)===opts.goodCats) && (opts.goodDogs==='either' || goodWithDogs(a)===opts.goodDogs) && (opts.goodChildren==='either' || goodWithChildren(a)===opts.goodChildren); }
      function scoreAnimal(a, opts){
        let score=0;
        if(opts.age==='either' || ageBand(a)===opts.age) score += 30;
        if(opts.sex==='either' || sexValue(a)===opts.sex) score += 10;
        if(opts.indoor==='either' || (opts.indoor==='yes' && hasIndoor(a)) || (opts.indoor==='no' && !hasIndoor(a))) score += 10;
        if(opts.bonded==='either' || (opts.bonded==='yes' && hasBonded(a)) || (opts.bonded==='no' && !hasBonded(a))) score += 10;
        if(opts.goodCats==='either' || goodWithCats(a)===opts.goodCats) score += 15;
        if(opts.goodDogs==='either' || goodWithDogs(a)===opts.goodDogs) score += 15;
        if(opts.goodChildren==='either' || goodWithChildren(a)===opts.goodChildren) score += 15;
        return score;
      }
	      function render(list){ const el=root.querySelector('#asm-quiz-results'); if(!list.length){ el.innerHTML='<p style="color:#6b7280;grid-column:1/-1;"><?php echo esc_js($q['results_empty_text'] ?? 'No exact matches were found. Please browse all adoptables instead.'); ?></p>'; return; } el.innerHTML=list.slice(0,6).map(a=>{ const name=safe(a.ANIMALNAME ?? a.AnimalName); const meta=[sexValue(a), safe(a.ANIMALAGE ?? a.AnimalAge), safe(a.BREEDNAME ?? a.BreedName ?? a.BREEDNAME1)].filter(Boolean).map(escHtml).join(' • '); const compat=['Cats: ' + goodWithCats(a),'Dogs: ' + goodWithDogs(a),'Children: ' + goodWithChildren(a)].map(escHtml).join(' • '); const url=modalLink(a); return `<a href="${escAttr(url)}" aria-label="View ${escAttr(name)}" style="display:block;background:#fff;border:2px solid var(--asm-quiz-brand);border-radius:20px;overflow:hidden;text-decoration:none;color:inherit;"><div style="aspect-ratio:1/1;background:#f3f4f6;"><img src="${escAttr(img(a))}" alt="${escAttr(name)}" style="width:100%;height:100%;object-fit:cover;display:block;" /></div><div style="padding:12px 14px;"><div style="font-weight:800;color:#111827;">${escHtml(name)}</div><div style="margin-top:.35rem;color:#6b7280;">${meta}</div><div style="margin-top:.5rem;color:#6b7280;font-size:.92rem;">${compat}</div></div></a>`; }).join(''); }
	      function updateSeo(list){ const data={"@context":"https://schema.org","@type":"ItemList","itemListElement":list.slice(0,6).map((a,i)=>({"@type":"ListItem","position":i+1,"item":{"@type":"Thing","additionalType":"https://schema.org/Animal","name":safe(a.ANIMALNAME ?? a.AnimalName),"description":safe(a.ANIMALCOMMENTS ?? a.DESCRIPTION ?? a.ANIMALDESCRIPTION),"image":img(a),"url":modalLink(a)}}))}; let tag=root.querySelector('script[type="application/ld+json"]'); if(!tag){ tag=document.createElement('script'); tag.type='application/ld+json'; root.appendChild(tag);} tag.textContent=JSON.stringify(data); }
      fetch(endpoint,{credentials:'same-origin'}).then(r=>r.json()).then(data=>{ animals=(Array.isArray(data)?data:[]).filter(a=>!hasPending(a)); const initial=animals.slice(0,3); render(initial); updateSeo(animals); }).catch(()=>render([]));
      root.querySelector('#asm-quiz-run').addEventListener('click',()=>{
        const opts={ age:root.querySelector('#asm-quiz-age').value, sex:root.querySelector('#asm-quiz-sex').value, indoor:(root.querySelector('#asm-quiz-indoor') ? root.querySelector('#asm-quiz-indoor').value : 'either'), bonded:root.querySelector('#asm-quiz-bonded').value, goodCats:root.querySelector('#asm-quiz-good-cats').value, goodDogs:root.querySelector('#asm-quiz-good-dogs').value, goodChildren:root.querySelector('#asm-quiz-good-children').value };
        let list=animals.filter(a=>matchesAll(a,opts));
        render(list); updateSeo(list);
      });
    })();</script>
    <?php return ob_get_clean();
  }


  public static function render_featured_shortcode($atts = []) {
    $settings = self::get_settings();
    $w = $settings['widgets'] ?? [];
    if (empty($w['featured_enabled'])) return '';
    $mode = $w['featured_mode'] ?? 'random';
    $manual = preg_replace('/\D+/', '', (string)($w['featured_manual_id'] ?? ''));
    $title = $w['featured_title_text'] ?? 'Featured animal';
    $subtitle = $w['featured_subtitle_text'] ?? 'Meet one of the animals looking for a home';
    $button = $w['featured_button_text'] ?? 'View animal';
    $adoptables_page_url = esc_url_raw($settings['global']['adoptables_page_url'] ?? '');
    ob_start(); ?>
    <section class="asm-featured-animal-widget" aria-labelledby="asm-featured-title" style="--asm-featured-brand:<?php echo esc_attr($settings['adoptables']['brand_color'] ?? '#401268'); ?>; --asm-featured-bg:<?php echo esc_attr($settings['adoptables']['background_color'] ?? '#fcf5fd'); ?>; background:var(--asm-featured-bg); border:2px solid var(--asm-featured-brand); border-radius:24px; padding:20px;">
      <div style="display:flex;flex-wrap:wrap;gap:20px;align-items:center;">
        <div style="flex:0 0 280px;max-width:100%;"><div style="aspect-ratio:1/1;background:#f3f4f6;border-radius:20px;overflow:hidden;"><img id="asm-featured-image" src="" alt="" style="width:100%;height:100%;object-fit:cover;display:block;" /></div></div>
        <div style="flex:1 1 320px;min-width:0;">
          <div style="font-size:12px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:#6b7280;">Featured</div>
          <h3 style="margin:.35rem 0 0;font-size:2rem;line-height:1.15;color:var(--asm-featured-brand);"><?php echo esc_html($title); ?></h3>
          <p style="margin:.4rem 0 1rem;color:#6b7280;"><?php echo esc_html($subtitle); ?></p>
          <div id="asm-featured-name" style="font-size:1.5rem;font-weight:800;color:#111827;">Loading…</div>
          <div id="asm-featured-meta" style="margin:.4rem 0 1rem;color:#4b5563;">Please wait</div>
          <a id="asm-featured-link" href="#" style="display:inline-flex;align-items:center;justify-content:center;padding:12px 18px;border-radius:999px;background:var(--asm-featured-brand);color:#fff;text-decoration:none;font-weight:700;"><?php echo esc_html($button); ?></a>
        </div>
      </div>
    </section>
    <script>(function(){
      const root=document.currentScript.previousElementSibling; if(!root) return;
      const endpoint=<?php echo wp_json_encode(rest_url('straysafe/v1/adoptables')); ?>;
      const adoptablesPageUrl=<?php echo wp_json_encode($adoptables_page_url); ?>;
      function slugifyPart(value){ return String(value || '').toLowerCase().replace(/&/g,' and ').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').replace(/-{2,}/g,'-'); }
      function animalModalSlug(animal){ const id=String(animal.ID ?? animal.ANIMALID ?? animal.AnimalID ?? '').replace(/\D+/g,''); const name=slugifyPart(animal.ANIMALNAME ?? animal.AnimalName ?? ''); const code=slugifyPart(animal.CODE ?? animal.SHELTERCODE ?? animal.ShelterCode ?? ''); return [name, code].filter(Boolean).join('-') || id; }
      function modalDeepLink(base,param,value){ const href=base || window.location.href; try { const url=new URL(href, window.location.origin); url.searchParams.set(param, value); return url.toString(); } catch(e) { const sep=String(href).includes('?') ? '&' : '?'; return String(href) + sep + encodeURIComponent(param) + '=' + encodeURIComponent(value); } }
      fetch(endpoint,{credentials:'same-origin'}).then(r=>r.json()).then(data=>{
        if(!Array.isArray(data)||!data.length) throw new Error('No animals');
        let animals=data.filter(a=>Number(a.SPECIESID ?? a.SpeciesID ?? 0)===2 || String(a.SPECIESNAME ?? a.SpeciesName ?? '').toLowerCase().includes('cat'));
        const mode=<?php echo wp_json_encode($mode); ?>;
        const manual=<?php echo wp_json_encode($manual); ?>;
        let animal=null;
        if(mode==='manual' && manual) animal=animals.find(a=>String(a.ID ?? a.ANIMALID ?? a.AnimalID ?? '')===String(manual));
        if(!animal && mode==='newest'){ animals.sort((a,b)=>Number(a.DAYSONSHELTER ?? a.DaysOnShelter ?? 0)-Number(b.DAYSONSHELTER ?? b.DaysOnShelter ?? 0)); animal=animals[0]; }
        if(!animal){ animal=animals[Math.floor(Math.random()*animals.length)]; }
        if(!animal) throw new Error('No animal');
        const id=String(animal.ID ?? animal.ANIMALID ?? animal.AnimalID ?? '');
        const name=String(animal.ANIMALNAME ?? animal.AnimalName ?? 'Animal');
        const age=String(animal.ANIMALAGE ?? animal.AnimalAge ?? '');
        const sex=String(animal.SEXNAME ?? animal.SexName ?? animal.SEX ?? '');
        const breed=String(animal.BREEDNAME ?? animal.BreedName ?? animal.BREEDNAME1 ?? '');
        const img=<?php echo wp_json_encode(rest_url('straysafe/v1/animal-image')); ?> + '?animalid=' + encodeURIComponent(id) + '&seq=1';
        root.querySelector('#asm-featured-image').src=img;
        root.querySelector('#asm-featured-image').alt=name;
        root.querySelector('#asm-featured-name').textContent=name;
        root.querySelector('#asm-featured-meta').textContent=[sex, age, breed].filter(Boolean).join(' • ');
        root.querySelector('#asm-featured-link').href=modalDeepLink(adoptablesPageUrl,'cat',animalModalSlug(animal)); const fl=root.querySelector('#asm-featured-link'); if(fl && !fl.dataset.bound){ fl.dataset.bound='1'; fl.addEventListener('click',()=>{ const body=new URLSearchParams(); body.set('action','asm_plugin_suite_track'); body.set('event','featured_widget_click'); fetch(<?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body:body.toString()}); }); }
      }).catch(err=>{ root.querySelector('#asm-featured-name').textContent='No featured animal available'; root.querySelector('#asm-featured-meta').textContent=''; root.querySelector('#asm-featured-link').style.display='none'; });
    })();</script>
    <?php return ob_get_clean();
  }

  public static function render_stories_shortcode($atts = []) {
    $settings = self::get_settings();
    $w = $settings['widgets'] ?? [];
    if (empty($w['stories_enabled'])) return '';
    $title = $w['stories_title_text'] ?? 'Adoption stories';
    $count = max(1, min(12, (int)($w['stories_count'] ?? 6)));
    $yearMode = $w['stories_year_mode'] ?? 'current';
    $year = $yearMode === 'current' ? date('Y') : '';
    $brand = $settings['adopted']['brand_color'] ?? '#401268';
    $bg = $settings['adopted']['background_color'] ?? '#fcf5fd';
    $text = $settings['adopted']['text_primary_color'] ?? '#374151';
    $muted = $settings['adopted']['text_muted_color'] ?? '#6b7280';
    $adopted_page_url = esc_url_raw($settings['global']['adopted_page_url'] ?? '');
    ob_start(); ?>
    <section class="asm-adoption-stories-widget" aria-labelledby="asm-stories-title" style="--asm-stories-brand:<?php echo esc_attr($brand); ?>; --asm-stories-bg:<?php echo esc_attr($bg); ?>; --asm-stories-text:<?php echo esc_attr($text); ?>; --asm-stories-muted:<?php echo esc_attr($muted); ?>; background:var(--asm-stories-bg); border-radius:24px; padding:20px;">
      <h2 id="asm-stories-title" style="margin:0 0 1rem;color:var(--asm-stories-brand);font-size:2rem;line-height:1.15;"><?php echo esc_html($title); ?></h2>
      <div id="asm-stories-grid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:20px;"></div>
    </section>
    <script>(function(){
      const root=document.currentScript.previousElementSibling; if(!root) return;
      const endpoint=<?php echo wp_json_encode(rest_url('straysafe/v1/adoptions')); ?> + '?speciesid=2' + (<?php echo wp_json_encode($year); ?> ? '&year=' + <?php echo wp_json_encode($year); ?> : '');
      const imageBase=<?php echo wp_json_encode(rest_url('straysafe/v1/animal-image')); ?>;
      const profileBase=<?php echo wp_json_encode(home_url('/happy-endings/')); ?>;
      const adoptedPageUrl=<?php echo wp_json_encode($adopted_page_url); ?>;
      function escHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
      function escAttr(s){ return escHtml(s).replace(/"/g,String.fromCharCode(38,113,117,111,116,59)).replace(/'/g,String.fromCharCode(38,35,48,51,57,59)); }
      function slugifyPart(value){ return String(value || '').toLowerCase().replace(/&/g,' and ').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').replace(/-{2,}/g,'-'); }
      function adoptedModalSlug(animal,id){ const name=slugifyPart(animal.ANIMALNAME ?? animal.AnimalName ?? ''); const code=slugifyPart(animal.CODE ?? animal.SHELTERCODE ?? animal.ShelterCode ?? ''); return [name, code].filter(Boolean).join('-') || id; }
      function adoptedStoryUrl(animal,id,name){ if(!adoptedPageUrl) return profileBase + encodeURIComponent(id + '-' + slugifyPart(name)) + '/'; try { const url=new URL(adoptedPageUrl, window.location.origin); url.searchParams.set('adopted', adoptedModalSlug(animal,id)); return url.toString(); } catch(e) { const sep=String(adoptedPageUrl).includes('?') ? '&' : '?'; return String(adoptedPageUrl) + sep + 'adopted=' + encodeURIComponent(adoptedModalSlug(animal,id)); } }
      fetch(endpoint,{credentials:'same-origin'}).then(r=>r.json()).then(data=>{
        if(!Array.isArray(data)||!data.length) throw new Error('No stories');
        data.sort((a,b)=>new Date(String(b.MOVEMENTDATE ?? b.MovementDate ?? 0)) - new Date(String(a.MOVEMENTDATE ?? a.MovementDate ?? 0)));
        const slice=data.slice(0, <?php echo (int)$count; ?>);
        const grid=root.querySelector('#asm-stories-grid');
        try { const body=new URLSearchParams(); body.set('action','asm_plugin_suite_track'); body.set('event','stories_widget_load'); fetch(<?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body:body.toString()}); } catch (e) {}
        grid.innerHTML=slice.map(a=>{ const id=String(a.ANIMALID ?? a.AnimalID ?? a.ID ?? '').replace(/\D+/g,''); const name=String(a.ANIMALNAME ?? a.AnimalName ?? 'Animal'); const age=String(a.ANIMALAGE ?? a.AnimalAge ?? '').trim(); const breed=String(a.BREEDNAME ?? a.BreedName ?? a.BREEDNAME1 ?? '').trim(); const sexRaw=String(a.SEXNAME ?? a.SexName ?? a.SEX ?? '').trim(); const sex=/^f/i.test(sexRaw) || sexRaw==='0' ? 'Female' : (/^m/i.test(sexRaw) || sexRaw==='1' ? 'Male' : sexRaw); const story=String(a.ANIMALCOMMENTS ?? a.WEBSITEMEDIANOTES ?? a.DESCRIPTION ?? a.ANIMALDESCRIPTION ?? '').replace(/\s+/g,' ').trim(); const snippet=story.length > 220 ? story.slice(0,217).trim() + '…' : story; const meta=[sex, age, breed].filter(Boolean).map(escHtml).join(' • '); const img=id ? imageBase + '?animalid=' + encodeURIComponent(id) + '&seq=1&_=' + Date.now() : ''; const url=adoptedStoryUrl(a,id,name); return `<article style="display:grid;grid-template-columns:minmax(0,190px) minmax(0,1fr);gap:18px;align-items:start;background:#fff;border:2px solid var(--asm-stories-brand);border-radius:24px;padding:16px;box-shadow:0 10px 24px rgba(15,23,42,.06);"><div style="border-radius:18px;overflow:hidden;background:#f3f4f6;line-height:0;aspect-ratio:1/1;">${id ? `<img src="${escAttr(img)}" alt="${escAttr(name)}" style="width:100%;height:100%;object-fit:cover;display:block;" loading="eager" decoding="async" />` : `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:42px;color:#9ca3af;line-height:1;">🐾</div>`}</div><div style="min-width:0;"><div style="font-weight:800;color:var(--asm-stories-text);font-size:1.08rem;line-height:1.25;"><a href="${escAttr(url)}" style="color:inherit;">${escHtml(name)}</a></div>${meta ? `<div style="margin-top:.45rem;color:var(--asm-stories-muted);line-height:1.55;">${meta}</div>` : ``}${snippet ? `<p style="margin:.85rem 0 0;color:var(--asm-stories-text);line-height:1.65;">${escHtml(snippet)}</p>` : `<p style="margin:.85rem 0 0;color:var(--asm-stories-muted);line-height:1.65;">Happy ending shared through our adopted cats updates.</p>`}</div></article>`; }).join('');
        if (window.matchMedia && window.matchMedia('(max-width: 640px)').matches) {
          grid.querySelectorAll('article').forEach(card => { card.style.gridTemplateColumns = '1fr'; });
        }
      }).catch(err=>{ const grid=root.querySelector('#asm-stories-grid'); grid.innerHTML='<p style="color:#6b7280;">No adoption stories available right now.</p>'; });
    })();</script>
    <?php return ob_get_clean();
  }

  public static function all_suite_shortcodes() {
    $settings = self::get_settings();
    $tags = [self::sanitize_shortcode_tag($settings['shortcodes']['adoptables'] ?? 'adoptables'), self::sanitize_shortcode_tag($settings['shortcodes']['adopted'] ?? 'adopted'), self::sanitize_shortcode_tag($settings['shortcodes']['statistics'] ?? 'stats')];
    foreach (self::get_forms() as $tag => $id) $tags[] = $tag;
    $tags[] = self::sanitize_shortcode_tag($settings['widgets']['featured_shortcode'] ?? 'featured_animal');
    $tags[] = self::sanitize_shortcode_tag($settings['widgets']['stories_shortcode'] ?? 'adoption_stories');
    $tags[] = self::sanitize_shortcode_tag($settings['quiz']['quiz_shortcode'] ?? 'adoption_match_quiz');
    return array_values(array_unique(array_filter($tags)));
  }

  public static function maybe_disable_cache_for_suite_pages() {
    if (!is_singular()) return;
    $post = get_queried_object();
    if (!$post || empty($post->post_content)) return;
    foreach (self::all_suite_shortcodes() as $tag) {
      if (has_shortcode($post->post_content, $tag)) {
        if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
        if (!defined('DONOTCACHEOBJECT')) define('DONOTCACHEOBJECT', true);
        if (!defined('DONOTCACHEDB')) define('DONOTCACHEDB', true);
        nocache_headers();
        return;
      }
    }
  }

  public static function admin_menu() {
    add_options_page('ASM Plugin Suite','ASM Plugin Suite','manage_options','straysafe-ui-suite',[__CLASS__,'render_settings_page']);
    add_submenu_page(null,'ASM Plugin Suite Setup','ASM Plugin Suite Setup','manage_options','straysafe-ui-suite-setup',[__CLASS__,'render_setup_wizard']);
  }

  public static function remove_legacy_admin_pages() {
    remove_submenu_page('options-general.php', 'straysafe-adoptables-ui');
    remove_submenu_page('options-general.php', 'straysafe-adopted-ui');
    remove_submenu_page('options-general.php', 'straysafe-stats-ui');
  }

  private static function sanitise_hex($value, $fallback) { $san = sanitize_hex_color($value); return $san ? $san : $fallback; }
  private static function sanitise_int($value, $fallback, $min, $max) { if ($value === '' || $value === null || !is_numeric($value)) $v = (int)$fallback; else $v = (int)$value; if($v<$min)$v=$min; if($v>$max)$v=$max; return $v; }
  private static function sanitise_float_string($value, $fallback, $min, $max) { $v = is_numeric($value)?(float)$value:(float)$fallback; if(!is_finite($v))$v=(float)$fallback; $v=max($min,min($max,$v)); return rtrim(rtrim(number_format($v,2,'.',''),'0'),'.'); }
  private static function sanitise_text($value, $fallback='') { $v=sanitize_text_field((string)$value); return $v===''?$fallback:$v; }
  private static function sanitise_textarea_csv($value) {
    $value = wp_unslash((string)$value);
    $value = str_replace(["\r\n", "\r", ";", "|"], ["\n", "\n", ',', ','], $value);
    $parts = preg_split('/[\n,]+/', $value);
    $parts = array_values(array_filter(array_map(function($item){
      return trim(wp_strip_all_tags((string)$item));
    }, (array)$parts)));
    return implode(',', $parts);
  }
  private static function sanitise_textarea($value, $fallback='') { $v=sanitize_textarea_field((string)$value); return $v===''?$fallback:$v; }
  private static function scaled($value, $scale_percent) { return max(10, min(80, (int) round($value * ($scale_percent / 100)))); }

  private static function get_style_behavior($settings=null) {
    if (!is_array($settings)) $settings = self::get_settings();
    $mode = $settings['global']['style_behavior'] ?? 'original_ui_defaults';
    return in_array($mode, ['original_ui_defaults','global_style_first'], true) ? $mode : 'original_ui_defaults';
  }

  private static function get_style_source($ui, $settings) {
    $key = $ui . '_style_source';
    $source = $settings['global'][$key] ?? 'auto';
    return in_array($source, ['auto','global','custom'], true) ? $source : 'auto';
  }

  private static function apply_global_style($section_key, $section, $global) {
    $section['brand_color'] = $global['brand_color'];
    $section['background_color'] = $global['background_color'];
    if (array_key_exists('modal_divider_color', $section)) $section['modal_divider_color'] = $global['modal_divider_color'];
    if (array_key_exists('text_primary_color', $section)) $section['text_primary_color'] = $global['text_primary_color'];
    if (array_key_exists('text_muted_color', $section)) $section['text_muted_color'] = $global['text_muted_color'];
    $section['paw_opacity'] = $global['paw_opacity'];
    $section['paw_count'] = $global['paw_count'];
    $section['font_family'] = $global['font_family'];
    $scale = intval($global['font_scale_percent']);
    if ($scale !== 100) {
      foreach ($section as $k => $v) if (strpos($k, 'fs_') === 0) $section[$k] = self::scaled((int)$v, $scale);
    }
    return $section;
  }

  private static function resolve_section_style($section_key, $section, $settings) {
    $source = self::get_style_source($section_key, $settings);
    if ($source === 'global') return self::apply_global_style($section_key, $section, $settings['global']);
    if ($source === 'custom') return $section;
    return self::get_style_behavior($settings) === 'global_style_first' ? self::apply_global_style($section_key, $section, $settings['global']) : $section;
  }

  private static function legacy_keys($section) {
    return array_keys(self::default_settings()[$section]);
  }

  private static function colour_keys($section) {
    $map = [
      'adoptables' => ['brand_color','background_color','modal_divider_color','card_border_color','apply_button_bg_color','apply_button_text_color','apply_button_border_color','bonded_label_bg_color','bonded_label_text_color','indoor_only_label_bg_color','indoor_only_label_text_color'],
      'adopted' => ['brand_color','background_color','text_primary_color','text_muted_color','card_border_color'],
      'stats' => ['brand_color','background_color','card_border_color'],
    ];
    return $map[$section] ?? [];
  }

  private static function float_keys($section) {
    return ['paw_opacity'];
  }
  private static function bool_keys($section) {
    return $section === 'adoptables' ? ['cats_only','show_top_navigation','show_reservation_label','show_pending_reservation_label','show_other_reservation_label','enable_deep_links','enable_apply_button','card_border_enabled','enable_filters','enable_filter_age','enable_filter_sex','enable_filter_breed','enable_exclude_pending_filter','detect_bonded_from_description','detect_indoor_only_from_description','enable_modal_slideshow_controls','enable_favourites','enable_compare_tool','enable_modals','enable_adoptables_modals'] : (($section === 'adopted') ? ['show_top_navigation','card_border_enabled','enable_modals','enable_deep_links','adoptables_cta_enabled'] : (($section === 'stats') ? ['card_border_enabled'] : []));
  }
  private static function textarea_keys($section) {
    $map = ['adoptables' => ['footer_text','modal_global_text','fallback_description'], 'adopted' => ['footer_text','modal_global_text'], 'stats' => ['footer_text','card_order']];
    return $map[$section] ?? [];
  }
  private static function select_keys($section) {
    $map = ['adoptables' => ['reservation_label_halign','reservation_label_valign','display_style','favourite_button_position'], 'adopted' => ['date_label_halign','date_label_valign','display_style'], 'stats' => ['layout_mode']];
    return $map[$section] ?? [];
  }
  private static function icon_keys($section) { return $section === 'stats' ? ['icon_brought','icon_adopted','icon_vaccinated','icon_neutered','icon_chipped','icon_in_care'] : []; }

  private static function sanitize_section($section, $input, $current = []) {
    $defaults = self::default_settings()[$section];
    $out = self::merge_with_defaults($defaults, is_array($current) ? $current : []);
    foreach (self::legacy_keys($section) as $key) {
      if (!array_key_exists($key, $input)) continue;
      if (in_array($key, self::colour_keys($section), true)) $out[$key] = self::sanitise_hex($input[$key] ?? '', $defaults[$key]);
      elseif (in_array($key, self::float_keys($section), true)) $out[$key] = self::sanitise_float_string($input[$key] ?? '', $defaults[$key], 0, 0.25);
      elseif (in_array($key, self::bool_keys($section), true)) $out[$key] = !empty($input[$key]) ? 1 : 0;
      elseif (in_array($key, self::textarea_keys($section), true)) $out[$key] = self::sanitise_textarea($input[$key] ?? '', $defaults[$key]);
      elseif (in_array($key, self::icon_keys($section), true)) $out[$key] = self::sanitize_icon_slug($input[$key] ?? $defaults[$key]);
      elseif ($section === 'adopted' && $key === 'adoptables_cta_url') $out[$key] = esc_url_raw($input[$key] ?? '');
      elseif (in_array($key, self::select_keys($section), true)) {
        $val = sanitize_key($input[$key] ?? $defaults[$key]);
        if ($section === 'adoptables' && $key === 'reservation_label_halign') $out[$key] = in_array($val, ['left','right'], true) ? $val : $defaults[$key];
        elseif ($section === 'adoptables' && $key === 'reservation_label_valign') $out[$key] = in_array($val, ['top','bottom'], true) ? $val : $defaults[$key];
        elseif ($section === 'adoptables' && $key === 'display_style') $out[$key] = in_array($val, ['classic','compact','list'], true) ? $val : $defaults[$key];
        elseif ($section === 'adoptables' && $key === 'favourite_button_position') $out[$key] = in_array($val, ['top_left','top_right','bottom_left','bottom_right','hidden'], true) ? $val : $defaults[$key];
        elseif ($section === 'adopted' && $key === 'date_label_halign') $out[$key] = in_array($val, ['left','right'], true) ? $val : $defaults[$key];
        elseif ($section === 'adopted' && $key === 'date_label_valign') $out[$key] = in_array($val, ['top','bottom'], true) ? $val : $defaults[$key];
        elseif ($section === 'adopted' && $key === 'display_style') $out[$key] = in_array($val, ['classic','compact','list'], true) ? $val : $defaults[$key];
        elseif ($section === 'stats' && $key === 'layout_mode') $out[$key] = in_array($val, ['grid','one_row'], true) ? $val : $defaults[$key];
      } else {
        $default = $defaults[$key];
        if (is_int($default)) {
          $min=0; $max=1200;
          if (strpos($key,'rows_')===0 or strpos($key,'cols_')===0) $max=12;
          elseif (strpos($key,'fs_')===0) {$min=10; $max=80;}
          elseif (strpos($key,'fw_')===0) {$min=100; $max=900;}
          elseif (in_array($key,['paw_count'],true)) {$min=0; $max=80;}
          elseif (in_array($key,['modal_max_width','card_w_mobile','card_w_tablet','card_w_desktop','card_h_mobile','card_h_tablet','card_h_desktop'],true)) {$min=0; $max=1600;}
          elseif (in_array($key,['card_radius','card_padding','button_radius','gap_x_mobile','gap_y_mobile','gap_x_tablet','gap_y_tablet','gap_x_desktop','gap_y_desktop','modal_divider_thickness','modal_divider_radius'],true)) {$min=0; $max=999;}
          elseif (in_array($key,['card_scale_mobile','card_scale_tablet','card_scale_desktop'],true)) {$min=50; $max=200;}
          elseif (in_array($key,['min_year'],true)) {$min=2000; $max=3000;}
          $out[$key] = self::sanitise_int($input[$key] ?? '', $default, $min, $max);
        } else {
          $out[$key] = self::sanitise_text($input[$key] ?? '', $default);
        }
      }
    }
    return $out;
  }

  public static function handle_save() {
    if (!current_user_can('manage_options')) wp_die('Permission denied.');
    check_admin_referer('straysafe_ui_suite_save');
    $active_tab = sanitize_key($_POST['active_tab'] ?? 'global');
    $active_subtab = sanitize_key($_POST['active_subtab'] ?? '');
    $input = isset($_POST['suite']) && is_array($_POST['suite']) ? wp_unslash($_POST['suite']) : [];
    $defaults = self::default_settings();
    $clean = self::get_settings();

    if ($active_tab === 'global') {
      $g = $input['global'] ?? [];
      $style_behavior = $g['style_behavior'] ?? ($clean['global']['style_behavior'] ?? $defaults['global']['style_behavior']);
      $clean['global']['style_behavior'] = in_array($style_behavior, ['original_ui_defaults','global_style_first'], true) ? $style_behavior : $defaults['global']['style_behavior'];
      foreach (['brand_color','background_color','modal_divider_color','text_primary_color','text_muted_color'] as $k) $clean['global'][$k] = self::sanitise_hex($g[$k] ?? '', $clean['global'][$k] ?? $defaults['global'][$k]);
      $clean['global']['paw_opacity'] = self::sanitise_float_string($g['paw_opacity'] ?? '', $clean['global']['paw_opacity'] ?? $defaults['global']['paw_opacity'], 0, 0.25);
      $clean['global']['paw_count'] = self::sanitise_int($g['paw_count'] ?? '', $clean['global']['paw_count'] ?? $defaults['global']['paw_count'], 0, 80);
      $clean['global']['font_family'] = preg_replace('/[^a-zA-Z0-9 ,\-]/', '', (string)($g['font_family'] ?? ($clean['global']['font_family'] ?? $defaults['global']['font_family'])));
      $clean['global']['font_scale_percent'] = self::sanitise_int($g['font_scale_percent'] ?? '', $clean['global']['font_scale_percent'] ?? $defaults['global']['font_scale_percent'], 50, 200);
      $clean['global']['cache_adoptables_seconds'] = self::sanitise_int($g['cache_adoptables_seconds'] ?? '', $clean['global']['cache_adoptables_seconds'] ?? $defaults['global']['cache_adoptables_seconds'], 0, 600);
      $clean['global']['cache_adopted_seconds'] = self::sanitise_int($g['cache_adopted_seconds'] ?? '', $clean['global']['cache_adopted_seconds'] ?? $defaults['global']['cache_adopted_seconds'], 0, 600);
      $clean['global']['cache_stats_seconds'] = self::sanitise_int($g['cache_stats_seconds'] ?? '', $clean['global']['cache_stats_seconds'] ?? $defaults['global']['cache_stats_seconds'], 0, 600);
      if (array_key_exists('bypass_cache', $g)) $clean['global']['bypass_cache'] = !empty($g['bypass_cache']) ? 1 : 0;
      foreach (['adoptables_page_url','adopted_page_url'] as $k) $clean['global'][$k] = esc_url_raw($g[$k] ?? ($clean['global'][$k] ?? ''));
      foreach (['adoptables_style_source','adopted_style_source','stats_style_source'] as $k) {
        $style_source = $g[$k] ?? ($clean['global'][$k] ?? 'auto');
        $clean['global'][$k] = in_array($style_source, ['auto','global','custom'], true) ? $style_source : ($clean['global'][$k] ?? 'auto');
      }
      $source = sanitize_key($g['data_source'] ?? ($clean['global']['data_source'] ?? 'asm'));
      $clean['global']['data_source'] = in_array($source, ['asm','custom_api'], true) ? $source : 'asm';
      $clean['global']['custom_api_url'] = esc_url_raw($g['custom_api_url'] ?? ($clean['global']['custom_api_url'] ?? ''));
      $clean['global']['custom_api_key'] = self::sanitise_text($g['custom_api_key'] ?? '', $clean['global']['custom_api_key'] ?? '');
      $clean['global']['custom_api_auth_header'] = preg_replace('/[^A-Za-z0-9\-]/', '', (string)($g['custom_api_auth_header'] ?? ($clean['global']['custom_api_auth_header'] ?? 'X-API-Key')));
      foreach (['custom_api_adoptables_url','custom_api_adoptions_url','custom_api_report_url','custom_api_incare_url','custom_api_image_url'] as $k) $clean['global'][$k] = esc_url_raw($g[$k] ?? ($clean['global'][$k] ?? ''));
      $clean['global']['shelterluv_api_key'] = self::sanitise_text($g['shelterluv_api_key'] ?? '', $clean['global']['shelterluv_api_key'] ?? '');
      $clean['global']['shelterluv_base_url'] = esc_url_raw($g['shelterluv_base_url'] ?? ($clean['global']['shelterluv_base_url'] ?? 'https://www.shelterluv.com'));
      $clean['global']['shelterluv_org_id'] = self::sanitise_text($g['shelterluv_org_id'] ?? '', $clean['global']['shelterluv_org_id'] ?? '');
      $clean['global']['shelterluv_statuses'] = self::sanitise_textarea_csv($g['shelterluv_statuses'] ?? ($clean['global']['shelterluv_statuses'] ?? 'adoptable,foster'));
      $clean['global']['shelterluv_location_ids'] = self::sanitise_textarea_csv($g['shelterluv_location_ids'] ?? ($clean['global']['shelterluv_location_ids'] ?? ''));
      $shelterluv_animal_type = $g['shelterluv_animal_type'] ?? ($clean['global']['shelterluv_animal_type'] ?? 'cat');
      $clean['global']['shelterluv_animal_type'] = in_array($shelterluv_animal_type, ['cat','cats','feline','any'], true) ? $shelterluv_animal_type : ($clean['global']['shelterluv_animal_type'] ?? 'cat');
      $clean['global']['petpoint_username'] = self::sanitise_text($g['petpoint_username'] ?? '', $clean['global']['petpoint_username'] ?? '');
      if (array_key_exists('petpoint_password', $g) && $g['petpoint_password'] !== '') {
        $clean['global']['petpoint_password'] = sanitize_text_field((string)$g['petpoint_password']);
      }
      $clean['global']['petpoint_base_url'] = esc_url_raw($g['petpoint_base_url'] ?? ($clean['global']['petpoint_base_url'] ?? ''));
      $clean['global']['petpoint_shelter_id'] = self::sanitise_text($g['petpoint_shelter_id'] ?? '', $clean['global']['petpoint_shelter_id'] ?? '');
      $clean['global']['petpoint_location_ids'] = self::sanitise_textarea_csv($g['petpoint_location_ids'] ?? ($clean['global']['petpoint_location_ids'] ?? ''));
      $clean['global']['petpoint_species_id'] = preg_replace('/[^0-9,]/', '', (string)($g['petpoint_species_id'] ?? ($clean['global']['petpoint_species_id'] ?? '2')));
      $clean['global']['petpoint_statuses'] = self::sanitise_textarea_csv($g['petpoint_statuses'] ?? ($clean['global']['petpoint_statuses'] ?? 'available,foster'));
      $clean['global']['petpoint_adopted_report_id'] = self::sanitise_text($g['petpoint_adopted_report_id'] ?? '', $clean['global']['petpoint_adopted_report_id'] ?? '');
    } elseif (in_array($active_tab, ['adoptables','adopted','stats'], true)) {
      $clean[$active_tab] = self::sanitize_section($active_tab, $input[$active_tab] ?? [], $clean[$active_tab] ?? []);
    } elseif ($active_tab === 'widgets') {
      $wi = $input['widgets'] ?? [];
      $clean['widgets']['featured_shortcode'] = self::sanitize_shortcode_tag($wi['featured_shortcode'] ?? ($clean['widgets']['featured_shortcode'] ?? $defaults['widgets']['featured_shortcode'])) ?: ($clean['widgets']['featured_shortcode'] ?? $defaults['widgets']['featured_shortcode']);
      $clean['widgets']['featured_enabled'] = !empty($wi['featured_enabled']) ? 1 : 0;
      $clean['widgets']['featured_mode'] = in_array(($wi['featured_mode'] ?? 'random'), ['random','newest','manual'], true) ? $wi['featured_mode'] : 'random';
      $clean['widgets']['featured_manual_id'] = preg_replace('/\D+/', '', (string)($wi['featured_manual_id'] ?? ''));
      foreach (['featured_title_text','featured_subtitle_text','featured_button_text'] as $k) $clean['widgets'][$k] = self::sanitise_text($wi[$k] ?? '', $defaults['widgets'][$k]);
      $clean['widgets']['stories_shortcode'] = self::sanitize_shortcode_tag($wi['stories_shortcode'] ?? ($clean['widgets']['stories_shortcode'] ?? $defaults['widgets']['stories_shortcode'])) ?: ($clean['widgets']['stories_shortcode'] ?? $defaults['widgets']['stories_shortcode']);
      $clean['widgets']['stories_enabled'] = !empty($wi['stories_enabled']) ? 1 : 0;
      $clean['widgets']['stories_title_text'] = self::sanitise_text($wi['stories_title_text'] ?? '', $defaults['widgets']['stories_title_text']);
      $clean['widgets']['stories_count'] = self::sanitise_int($wi['stories_count'] ?? '', $clean['widgets']['stories_count'] ?? $defaults['widgets']['stories_count'], 1, 12);
      $clean['widgets']['stories_year_mode'] = in_array(($wi['stories_year_mode'] ?? 'current'), ['current','all'], true) ? $wi['stories_year_mode'] : 'current';
    } elseif ($active_tab === 'quiz') {
      $q = $input['quiz'] ?? [];
      $clean['quiz']['quiz_shortcode'] = self::sanitize_shortcode_tag($q['quiz_shortcode'] ?? ($clean['quiz']['quiz_shortcode'] ?? $defaults['quiz']['quiz_shortcode'])) ?: ($clean['quiz']['quiz_shortcode'] ?? $defaults['quiz']['quiz_shortcode']);
      $clean['quiz']['quiz_enabled'] = !empty($q['quiz_enabled']) ? 1 : 0;
      foreach (['quiz_title_text','quiz_intro_text','q1_text','q1_kitten_label','q1_adult_label','q1_senior_label','q1_either_label','q2_text','q2_female_label','q2_male_label','q2_either_label','q3_text','q3_yes_label','q3_no_label','results_title_text','results_empty_text','age_categories'] as $k) $clean['quiz'][$k] = self::sanitise_text($q[$k] ?? '', $defaults['quiz'][$k]);
      $clean['quiz']['q3_hide'] = !empty($q['q3_hide']) ? 1 : 0;
    } elseif ($active_tab === 'forms') {
      $sc = $input['shortcodes'] ?? [];
      foreach (['adoptables','adopted','statistics'] as $k) $clean['shortcodes'][$k] = self::sanitize_shortcode_tag($sc[$k] ?? ($clean['shortcodes'][$k] ?? $defaults['shortcodes'][$k])) ?: ($clean['shortcodes'][$k] ?? $defaults['shortcodes'][$k]);
      $fo = $input['forms'] ?? [];
      $clean['forms']['account'] = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string)($fo['account'] ?? ($clean['forms']['account'] ?? $defaults['forms']['account'])));
      $clean['forms']['items'] = [];
      $items = isset($fo['items']) && is_array($fo['items']) ? $fo['items'] : [];
      for ($i=0; $i<10; $i++) {
        $row = isset($items[$i]) && is_array($items[$i]) ? $items[$i] : [];
        $clean['forms']['items'][] = ['shortcode' => self::sanitize_shortcode_tag($row['shortcode'] ?? ''), 'form_id' => preg_replace('/[^0-9]/', '', (string)($row['form_id'] ?? ''))];
      }
    } elseif ($active_tab === 'proxy') {
      $pr = $input['proxy'] ?? [];
      $clean['proxy']['base_url'] = esc_url_raw($pr['base_url'] ?? ($clean['proxy']['base_url'] ?? $defaults['proxy']['base_url']));
      $clean['proxy']['account'] = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string)($pr['account'] ?? ($clean['proxy']['account'] ?? '')));
      $clean['proxy']['username'] = sanitize_text_field((string)($pr['username'] ?? ($clean['proxy']['username'] ?? '')));
      if (array_key_exists('password', $pr) && $pr['password'] !== '') {
        $clean['proxy']['password'] = (string)$pr['password'];
      }
      $clean['proxy']['cache_adoptables_seconds'] = self::sanitise_int($pr['cache_adoptables_seconds'] ?? '', $clean['proxy']['cache_adoptables_seconds'] ?? $defaults['proxy']['cache_adoptables_seconds'], 0, 600);
      $clean['proxy']['cache_reports_seconds'] = self::sanitise_int($pr['cache_reports_seconds'] ?? '', $clean['proxy']['cache_reports_seconds'] ?? $defaults['proxy']['cache_reports_seconds'], 0, 600);
      $clean['proxy']['cache_incare_seconds'] = self::sanitise_int($pr['cache_incare_seconds'] ?? '', $clean['proxy']['cache_incare_seconds'] ?? $defaults['proxy']['cache_incare_seconds'], 0, 600);
      $clean['proxy']['cache_adoptions_seconds'] = self::sanitise_int($pr['cache_adoptions_seconds'] ?? '', $clean['proxy']['cache_adoptions_seconds'] ?? $defaults['proxy']['cache_adoptions_seconds'], 0, 3600);
    }

    self::create_snapshot('save');
    update_option(self::OPT_KEY, $clean, false);
    self::define_proxy_constants_from_settings($clean);
    $args=['page'=>'straysafe-ui-suite','tab'=>$active_tab,'updated'=>'true']; if($active_subtab!=='') $args['subtab']=$active_subtab; wp_safe_redirect(add_query_arg($args, admin_url('options-general.php')));
    exit;
  }


  public static function handle_save_current_defaults() {
    if (!current_user_can('manage_options')) wp_die('Not allowed');
    check_admin_referer('straysafe_ui_suite_save_current_defaults');
    update_option(self::USER_DEFAULTS_KEY, self::get_settings(), false);
    wp_safe_redirect(add_query_arg(['page'=>'straysafe-ui-suite','saved_defaults'=>'1'], admin_url('options-general.php')));
    exit;
  }

  public static function handle_reset_defaults() {
    if (!current_user_can('manage_options')) wp_die('Permission denied.');
    check_admin_referer('straysafe_ui_suite_reset_defaults');
    self::create_snapshot('reset_defaults');
    $defaults = self::default_settings();
    update_option(self::OPT_KEY, $defaults, false);
    self::sync_legacy_options($defaults);
    wp_safe_redirect(add_query_arg(['page'=>'straysafe-ui-suite','tab'=>'global','updated'=>'defaults-reset'], admin_url('options-general.php')));
    exit;
  }

  public static function sync_legacy_options_from_db($old, $new) {
    self::sync_legacy_options(is_array($new) ? $new : self::get_settings());
  }

  public static function sync_legacy_options($settings) {
    if (!is_array($settings)) $settings = self::default_settings();
    if (class_exists('StraySafe_Adoptables_UI_Shortcode')) update_option(StraySafe_Adoptables_UI_Shortcode::OPT_KEY, self::resolve_section_style('adoptables', array_merge(StraySafe_Adoptables_UI_Shortcode::default_options(), $settings['adoptables']), $settings));
    if (class_exists('StraySafe_Adopted_UI_Shortcode')) update_option(StraySafe_Adopted_UI_Shortcode::OPT_KEY, self::resolve_section_style('adopted', array_merge(StraySafe_Adopted_UI_Shortcode::default_options(), $settings['adopted']), $settings));
    if (function_exists('straysafe_stats_ui_default_options')) update_option('straysafe_stats_ui_options', self::resolve_section_style('stats', array_merge(straysafe_stats_ui_default_options(), $settings['stats']), $settings));
  }

  public static function handle_export() {
    if (!current_user_can('manage_options')) wp_die('Permission denied.');
    check_admin_referer('straysafe_ui_suite_export');
    $payload = [
      'suite' => self::exportable_settings(self::get_settings()),
      'legacy' => [
        'adoptables' => get_option('straysafe_adoptables_ui_options', []),
        'adopted' => get_option('straysafe_adopted_ui_options', []),
        'stats' => get_option('straysafe_stats_ui_options', []),
      ],
    ];
    nocache_headers();
    header('Content-Type: application/json; charset=' . get_bloginfo('charset'));
    header('Content-Disposition: attachment; filename=straysafe-ui-suite-settings.json');
    echo wp_json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
  }

  public static function handle_import() {
    if (!current_user_can('manage_options')) wp_die('Permission denied.');
    check_admin_referer('straysafe_ui_suite_import');
    if (empty($_FILES['import_file']['tmp_name'])) wp_die('No import file uploaded.');
    $json = file_get_contents($_FILES['import_file']['tmp_name']);
    $data = json_decode($json, true);
    if (!is_array($data)) wp_die('Invalid import file.');
    self::create_snapshot('import');
    if (!empty($data['suite']) && is_array($data['suite'])) {
      $merged = array_replace_recursive(self::default_settings(), $data['suite']);
      $existing = self::get_settings();
      if (isset($existing['proxy']) && is_array($existing['proxy'])) {
        foreach (['account','username','password'] as $secret_key) {
          if (empty($merged['proxy'][$secret_key]) && !empty($existing['proxy'][$secret_key])) $merged['proxy'][$secret_key] = $existing['proxy'][$secret_key];
        }
      }
      if (isset($existing['global']) && is_array($existing['global'])) {
        foreach (['custom_api_key','shelterluv_api_key','petpoint_username','petpoint_password'] as $secret_key) {
          if (empty($merged['global'][$secret_key]) && !empty($existing['global'][$secret_key])) $merged['global'][$secret_key] = $existing['global'][$secret_key];
        }
      }
      update_option(self::OPT_KEY, $merged, false);
    }
    if (!empty($data['legacy']) && is_array($data['legacy'])) {
      if (isset($data['legacy']['adoptables']) && is_array($data['legacy']['adoptables'])) update_option('straysafe_adoptables_ui_options', $data['legacy']['adoptables']);
      if (isset($data['legacy']['adopted']) && is_array($data['legacy']['adopted'])) update_option('straysafe_adopted_ui_options', $data['legacy']['adopted']);
      if (isset($data['legacy']['stats']) && is_array($data['legacy']['stats'])) update_option('straysafe_stats_ui_options', $data['legacy']['stats']);
    }
    self::sync_legacy_options(self::get_settings());
    wp_safe_redirect(add_query_arg(['page'=>'straysafe-ui-suite','tab'=>'global','updated'=>'imported'], admin_url('options-general.php')));
    exit;
  }

  private static function field_name($section,$key){ return 'suite['.$section.']['.$key.']'; }
  private static function text_input($section,$key,$value,$class='regular-text'){ printf('<input type="text" name="%s" value="%s" class="%s" />', esc_attr(self::field_name($section,$key)), esc_attr($value), esc_attr($class)); }
  private static function number_input($section,$key,$value,$min,$max,$step=1){ printf('<input type="number" name="%s" value="%s" min="%s" max="%s" step="%s" class="small-text" />', esc_attr(self::field_name($section,$key)), esc_attr($value), esc_attr($min), esc_attr($max), esc_attr($step)); }
  private static function colour_input($section,$key,$value){ printf('<input type="color" name="%s" value="%s" /> <code>%s</code>', esc_attr(self::field_name($section,$key)), esc_attr($value), esc_html($value)); }
  private static function checkbox_input($section,$key,$checked,$label){ $name = self::field_name($section,$key); printf('<input type="hidden" name="%s" value="0" /><label><input type="checkbox" name="%s" value="1" %s /> %s</label>', esc_attr($name), esc_attr($name), checked(!empty($checked), true, false), esc_html($label)); }
  private static function textarea_input($section,$key,$value,$rows=4){ printf('<textarea name="%s" rows="%d" class="large-text">%s</textarea>', esc_attr(self::field_name($section,$key)), (int)$rows, esc_textarea($value)); }
  private static function select_input($section,$key,$value,$options){ printf('<select name="%s">', esc_attr(self::field_name($section,$key))); foreach($options as $ov=>$ol) printf('<option value="%s" %s>%s</option>', esc_attr($ov), selected((string)$value,(string)$ov,false), esc_html($ol)); echo '</select>'; }
  private static function icon_options(){ return ['heart'=>'Heart','home'=>'Home','syringe'=>'Syringe','stethoscope'=>'Stethoscope','map_pin'=>'Map Pin','shield'=>'Shield','tag'=>'Tag','scissors'=>'Scissors','handshake'=>'Handshake','house_heart'=>'House + Heart','users'=>'People','clipboard'=>'Clipboard','calendar'=>'Calendar','check'=>'Check','chart'=>'Chart','info'=>'Info','heartbeat'=>'Heartbeat','bandage'=>'Bandage','pill'=>'Pill','id_card'=>'ID Card','qr'=>'Scan / QR','shield_check'=>'Shield + Check','pawprints_a'=>'Paw Prints A','pawprints_b'=>'Paw Prints B','pawprints_c'=>'Paw Prints C','pawprints_d'=>'Paw Prints Cute','pawprints_e'=>'Paw Prints Bold']; }
  private static function sanitize_icon_slug($v){ $v=sanitize_key((string)$v); return array_key_exists($v,self::icon_options())?$v:'heart'; }
  private static function sortable_list($name,$values,$labels){
    $current=[];
    if (!is_array($values)) $values=[];
    foreach ($values as $v){ $v=sanitize_key((string)$v); if($v!=='' && isset($labels[$v]) && !in_array($v,$current,true)) $current[]=$v; }
    foreach (array_keys($labels) as $v){ if(!in_array($v,$current,true)) $current[]=$v; }
    echo '<ul class="ss-sortable">';
    foreach ($current as $v){ echo '<li draggable="true" data-value="'.esc_attr($v).'"><span>'.esc_html($labels[$v]).'</span><span class="dashicons dashicons-move"></span></li>'; }
    echo '</ul>';
    printf('<textarea class="ss-sortable-input" name="%s" rows="6" style="display:none;">%s</textarea>', esc_attr($name), esc_textarea(implode("
",$current)));
  }
  private static function preview_url($ui,$device='desktop'){ return wp_nonce_url(add_query_arg(['action'=>'straysafe_ui_suite_preview','ui'=>$ui,'device'=>$device], admin_url('admin-post.php')), 'straysafe_ui_suite_preview_'.$ui.'_'.$device); }

  public static function render_preview() {
    if (!current_user_can('manage_options')) wp_die('Permission denied.');
    $ui = sanitize_key($_GET['ui'] ?? 'adoptables');
    $device = sanitize_key($_GET['device'] ?? 'desktop');
    if (!in_array($ui,['adoptables','adopted','stats','widgets_featured','widgets_stories','quiz'],true)) $ui='adoptables';
    if (!in_array($device,['mobile','tablet','desktop'],true)) $device='desktop';
    check_admin_referer('straysafe_ui_suite_preview_'.$ui.'_'.$device);
    self::sync_legacy_options(self::get_settings());
    $widths=['mobile'=>430,'tablet'=>900,'desktop'=>1280]; $width=$widths[$device];
    $settings = self::get_settings();
    $shortcodes=['adoptables'=>self::sanitize_shortcode_tag($settings['shortcodes']['adoptables'] ?? 'adoptables'),'adopted'=>self::sanitize_shortcode_tag($settings['shortcodes']['adopted'] ?? 'adopted'),'stats'=>self::sanitize_shortcode_tag($settings['shortcodes']['statistics'] ?? 'stats'),'widgets_featured'=>self::sanitize_shortcode_tag($settings['widgets']['featured_shortcode'] ?? 'featured_animal'),'widgets_stories'=>self::sanitize_shortcode_tag($settings['widgets']['stories_shortcode'] ?? 'adoption_stories'),'quiz'=>self::sanitize_shortcode_tag($settings['quiz']['quiz_shortcode'] ?? 'adoption_match_quiz')];
    $tag = $shortcodes[$ui] ?? 'adoptables';
    $html=do_shortcode('['.$tag.']');
    status_header(200); nocache_headers(); ?>
<!doctype html><html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php do_action('wp_head'); ?><style>body{margin:0;padding:16px;background:#eef1f5;font-family:Arial,sans-serif}.ss-preview-shell{width:min(100%,<?php echo (int)$width; ?>px);margin:0 auto;background:#fff;border:1px solid #d0d7de;border-radius:16px;overflow:hidden;box-shadow:0 8px 30px rgba(0,0,0,.08)}.ss-preview-bar{padding:10px 14px;background:#f6f8fa;border-bottom:1px solid #d8dee4;font-size:12px;font-weight:600;color:#344054}</style></head><body><div class="ss-preview-shell"><div class="ss-preview-bar"><?php echo esc_html(ucfirst($ui).' preview · '.ucfirst($device)); ?></div><?php echo $html; ?></div><?php do_action('wp_footer'); ?></body></html><?php exit; }

  private static function preview_frame($ui) {
    echo '<div class="ss-suite-card" style="grid-column:1/-1;">';
    echo '<div class="ss-suite-preview-header"><h2 style="margin:0;">Live preview</h2><div class="ss-suite-preview-switch">';
    foreach (['mobile'=>'Mobile','tablet'=>'Tablet','desktop'=>'PC'] as $device=>$label) printf('<button type="button" class="button ss-preview-btn" data-ui="%1$s" data-src="%2$s">%3$s</button> ', esc_attr($ui), esc_url(self::preview_url($ui,$device)), esc_html($label));
    echo '</div></div>';
    printf('<iframe class="ss-suite-preview-frame" id="ss-preview-%1$s" src="%2$s" loading="lazy"></iframe>', esc_attr($ui), esc_url(self::preview_url($ui,'desktop')));
    echo '</div>';
  }

  private static function preview_frame_custom($ui, $title = 'Live preview') {
    echo '<div class="ss-suite-card" style="grid-column:1/-1;">';
    echo '<div class="ss-suite-preview-header"><h2 style="margin:0;">'.esc_html($title).'</h2><div class="ss-suite-preview-switch">';
    foreach (['mobile'=>'Mobile','tablet'=>'Tablet','desktop'=>'PC'] as $device=>$label) printf('<button type="button" class="button ss-preview-btn" data-ui="%1$s" data-src="%2$s">%3$s</button> ', esc_attr($ui), esc_url(self::preview_url($ui,$device)), esc_html($label));
    echo '</div></div>';
    printf('<iframe class="ss-suite-preview-frame" id="ss-preview-%1$s" src="%2$s" loading="lazy"></iframe>', esc_attr($ui), esc_url(self::preview_url($ui,'desktop')));
    echo '</div>';
  }

  private static function row($label,$html){ echo '<tr><th>'.$label.'</th><td>'.$html.'</td></tr>'; }
  private static function start_wrap(){ ?>
    <style>
      .ss-suite-tabs{display:flex;gap:8px;margin:18px 0 22px;flex-wrap:wrap}.ss-suite-tab{padding:10px 14px;border:1px solid #ccd0d4;border-bottom:none;background:#f6f7f7;text-decoration:none;color:#1d2327;border-radius:6px 6px 0 0}.ss-suite-tab.active{background:#fff;font-weight:600}.ss-suite-panel{background:#fff;border:1px solid #ccd0d4;padding:22px;max-width:1450px}.ss-suite-panel .form-table tr{display:table-row}.ss-suite-panel .form-table th,.ss-suite-panel .form-table td{padding:10px 8px;vertical-align:top}.ss-suite-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px;align-items:start}.ss-suite-card{border:1px solid #e2e4e7;border-radius:10px;padding:16px;background:#fcfcfc;min-width:0}.ss-suite-card h2,.ss-suite-card h3{margin-top:0}.ss-suite-inline{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.ss-suite-table{width:100%;border-collapse:collapse}.ss-suite-table th,.ss-suite-table td{padding:10px 8px;border-top:1px solid #e2e4e7;vertical-align:top;text-align:left}.ss-suite-card .form-table{width:100%;table-layout:fixed}.ss-suite-card .form-table th{width:210px;max-width:210px;white-space:normal;word-break:break-word}.ss-suite-card .form-table td{overflow-wrap:anywhere}.ss-suite-card input[type=text],.ss-suite-card textarea,.ss-suite-card select,.ss-suite-card .regular-text,.ss-suite-card .large-text{width:100%;max-width:100%}.ss-suite-card input.small-text{width:72px;max-width:100%}.ss-suite-card input[type=color]{width:48px;min-width:48px;padding:0}.ss-suite-save{margin-top:20px}.ss-suite-preview-header{display:flex;gap:12px;justify-content:space-between;align-items:center;flex-wrap:wrap;margin-bottom:12px}.ss-suite-preview-switch{display:flex;gap:8px;flex-wrap:wrap}.ss-suite-preview-frame{width:100%;height:880px;border:1px solid #d0d7de;border-radius:12px;background:#fff}.ss-suite-note{padding:12px 14px;background:#f6f7f7;border:1px solid #e2e4e7;border-radius:8px}.ss-subgrid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.ss-triplet{display:grid;grid-template-columns:150px 1fr 1fr 1fr 1fr;gap:8px;align-items:center}.ss-triplet>div{min-width:0}.ss-suite-actions{display:flex;gap:12px;align-items:center;flex-wrap:wrap}.ss-sortable{list-style:none;margin:0;padding:0;border:1px solid #d0d7de;border-radius:10px;background:#fff}.ss-sortable li{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:10px 12px;border-top:1px solid #eef2f6;cursor:move}.ss-sortable li:first-child{border-top:none}.ss-sortable li.dragging{opacity:.45}.ss-sortable .dashicons{color:#6b7280}.ss-suite-subnav{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 18px}.ss-suite-subnav a{display:inline-block;padding:8px 12px;border:1px solid #d0d7de;border-radius:8px;background:#f6f7f7;text-decoration:none;color:#1d2327}.ss-suite-subnav a.active{background:#401268;color:#fff;border-color:#401268}.ss-suite-subsection{display:none}.ss-suite-subsection.active{display:block}
      @media (max-width: 1200px){.ss-suite-grid,.ss-subgrid{grid-template-columns:1fr}.ss-triplet{grid-template-columns:1fr}}
    </style>
  <?php }

  public static function render_settings_page() {
    if (!current_user_can('manage_options')) return;
    $settings = self::get_settings();
    $tab = sanitize_key($_GET['tab'] ?? 'global');
    if (!in_array($tab,['global','adoptables','layout','adopted','stats','widgets','quiz','forms','proxy','diagnostics'], true)) $tab='global';
    echo '<div class="wrap"><h1>ASM Plugin Suite</h1><p>Default shortcodes: <code>[adoptables]</code> <code>[adopted]</code> <code>[stats]</code> <code>[adoption_form]</code> <code>[volunteer_form]</code> <code>[waiting_list_form]</code> <code>[lost_cat_form]</code></p>';
    if (!empty($_GET['updated'])) echo '<div class="notice notice-success is-dismissible"><p>Settings saved.</p></div>';
    if (!empty($_GET['ss_msg'])) echo '<div class="notice notice-info is-dismissible"><p>' . esc_html(wp_unslash($_GET['ss_msg'])) . '</p></div>';
    self::start_wrap();
    echo '<div class="ss-suite-tabs">';
    foreach (['global'=>'Global','adoptables'=>'Adoptables','layout'=>'Layout builder','adopted'=>'Adopted','stats'=>'Statistics','widgets'=>'Widgets','quiz'=>'Match quiz','forms'=>'Forms','proxy'=>'Proxy','diagnostics'=>'Diagnostics'] as $key=>$label) printf('<a class="ss-suite-tab %s" href="%s">%s</a>', $tab===$key?'active':'', esc_url(add_query_arg(['page'=>'straysafe-ui-suite','tab'=>$key], admin_url('options-general.php'))), esc_html($label));
    echo '</div><div class="ss-suite-panel">';
    if ($tab === 'global') self::render_global_tab($settings);
    elseif ($tab === 'adoptables') self::render_adoptables_tab($settings['adoptables'], $settings['global']);
    elseif ($tab === 'layout') self::render_layout_tab($settings);
    elseif ($tab === 'adopted') self::render_adopted_tab($settings['adopted'], $settings['global']);
    elseif ($tab === 'stats') self::render_stats_tab($settings['stats'], $settings['global']);
    elseif ($tab === 'widgets') self::render_widgets_tab($settings);
    elseif ($tab === 'quiz') self::render_quiz_tab($settings);
    elseif ($tab === 'forms') self::render_forms_tab($settings);
    elseif ($tab === 'proxy') self::render_proxy_tab($settings);
    else self::render_diagnostics_tab($settings);
    echo "</div><script>(function(){document.addEventListener('click',function(e){const btn=e.target.closest('.ss-preview-btn');if(!btn)return;const frame=document.getElementById('ss-preview-'+btn.dataset.ui);if(frame&&btn.dataset.src)frame.src=btn.dataset.src;});document.querySelectorAll('.ss-sortable').forEach(function(list){if(!list||list.dataset.bound==='1')return;list.dataset.bound='1';let dragged=null;const sync=function(){const input=list.nextElementSibling;if(!input||!input.classList.contains('ss-sortable-input'))return;input.value=Array.from(list.querySelectorAll('li[data-value]')).map(function(li){return li.dataset.value||'';}).filter(Boolean).join('\n');};list.querySelectorAll('li').forEach(function(item){item.addEventListener('dragstart',function(){dragged=item;item.classList.add('dragging');});item.addEventListener('dragend',function(){item.classList.remove('dragging');dragged=null;sync();});});list.addEventListener('dragover',function(e){e.preventDefault();if(!dragged)return;const items=Array.from(list.querySelectorAll('li:not(.dragging)'));const after=items.find(function(el){const r=el.getBoundingClientRect();return e.clientY<r.top+r.height/2;});if(!after)list.appendChild(dragged);else list.insertBefore(dragged,after);});sync();});})();</script></div>";
  }

  private static function form_start($tab){ $subtab=sanitize_key($_GET['subtab'] ?? ''); echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; wp_nonce_field('straysafe_ui_suite_save'); echo '<input type="hidden" name="action" value="straysafe_ui_suite_save" /><input type="hidden" name="active_tab" value="'.esc_attr($tab).'" /><input type="hidden" name="active_subtab" value="'.esc_attr($subtab).'" />'; }
  private static function form_end(){ echo '<p class="ss-suite-save">'; submit_button('Save changes','primary','submit',false); echo '</p></form>'; }

  private static function render_global_tab($s) {
    echo '<div class="ss-suite-grid">';

    self::form_start('global');
    echo '<div class="ss-suite-card"><h2>Global behaviour</h2><table class="form-table">';
    ob_start(); self::select_input('global','style_behavior',$s['global']['style_behavior'], ['original_ui_defaults'=>'Original UI defaults first','global_style_first'=>'Global style first']); self::row('UI style behaviour', ob_get_clean());
    foreach ([['cache_adoptables_seconds','Adoptables cache seconds'],['cache_adopted_seconds','Adopted cache seconds'],['cache_stats_seconds','Statistics cache seconds']] as $r){ ob_start(); self::number_input('global',$r[0],$s['global'][$r[0]],0,600); self::row($r[1], ob_get_clean()); }
    ob_start(); self::checkbox_input('global','bypass_cache',$s['global']['bypass_cache'] ?? 0,'Bypass suite transients and request fresh ASM/Custom API data'); self::row('Cache bypass', ob_get_clean() . '<p class="description">When enabled, adoptables, adopted animals, statistics and SEO profile feeds skip the plugin cache. This may increase requests to ASM or your custom API.</p>');
    self::row('Adoptables UI page URL', '<input type="url" name="suite[global][adoptables_page_url]" value="' . esc_attr($s['global']['adoptables_page_url'] ?? '') . '" class="regular-text code" placeholder="' . esc_attr(home_url('/adopt/')) . '" /><p class="description">Used by the featured animal widget and adoptable modal share links. Set this to the page containing the Adoptables UI shortcode.</p>');
    self::row('Adopted UI page URL', '<input type="url" name="suite[global][adopted_page_url]" value="' . esc_attr($s['global']['adopted_page_url'] ?? '') . '" class="regular-text code" placeholder="' . esc_attr(home_url('/happy-endings/')) . '" /><p class="description">Used by adopted modal share links and adoption story widgets. Set this to the page containing the Adopted UI shortcode.</p>');
    ob_start(); self::select_input('global','adoptables_style_source',$s['global']['adoptables_style_source'],['auto'=>'Auto','global'=>'Always use global','custom'=>'Always use custom']); self::row('Adoptables style source', ob_get_clean());
    ob_start(); self::select_input('global','adopted_style_source',$s['global']['adopted_style_source'],['auto'=>'Auto','global'=>'Always use global','custom'=>'Always use custom']); self::row('Adopted style source', ob_get_clean());
    ob_start(); self::select_input('global','stats_style_source',$s['global']['stats_style_source'],['auto'=>'Auto','global'=>'Always use global','custom'=>'Always use custom']); self::row('Statistics style source', ob_get_clean());
    echo '</table><div class="ss-suite-note"><strong>How Auto works</strong><br>Original UI defaults first keeps each UI on its own settings by default.<br>Global style first makes each UI inherit the Global tab values unless that UI is set to Custom.</div>';
    self::form_end();
    echo '</div>';

    self::form_start('global');
    echo '<div class="ss-suite-card"><h2>Data source</h2><table class="form-table">';
    ob_start(); self::select_input('global','data_source',$s['global']['data_source'] ?? 'asm', ['asm'=>'Animal Shelter Manager (ASM)','custom_api'=>'Custom API']); self::row('Live source', ob_get_clean());
    self::row('Custom API base URL', '<input type="url" name="suite[global][custom_api_url]" value="' . esc_attr($s['global']['custom_api_url'] ?? '') . '" class="regular-text code" placeholder="https://example.org/api" /><p class="description">Optional. If endpoint fields are blank, the suite derives /adoptables, /adoptions, /report, /in-care-count and /animal-image from this base.</p>');
    foreach ([
      'custom_api_adoptables_url' => ['Adoptables endpoint','https://example.org/api/adoptables'],
      'custom_api_adoptions_url' => ['Adoptions endpoint','https://example.org/api/adoptions'],
      'custom_api_report_url' => ['Report endpoint','https://example.org/api/report'],
      'custom_api_incare_url' => ['In-care endpoint','https://example.org/api/in-care-count'],
      'custom_api_image_url' => ['Image endpoint','https://example.org/api/animal-image'],
    ] as $key => $meta) {
      self::row($meta[0], '<input type="url" name="suite[global][' . esc_attr($key) . ']" value="' . esc_attr($s['global'][$key] ?? '') . '" class="regular-text code" placeholder="' . esc_attr($meta[1]) . '" />');
    }
    self::row('Auth header', '<input type="text" name="suite[global][custom_api_auth_header]" value="' . esc_attr($s['global']['custom_api_auth_header'] ?? 'X-API-Key') . '" class="regular-text" />');
    self::row('Custom API key', '<input type="password" name="suite[global][custom_api_key]" value="' . esc_attr($s['global']['custom_api_key'] ?? '') . '" class="regular-text" autocomplete="new-password" /><p class="description">Saved securely in WordPress options and excluded from suite exports.</p>');
    echo '</table><div class="ss-suite-note"><strong>Source routing</strong><br>ASM uses the Proxy tab credentials. Custom API is now a live source and should return JSON arrays, or objects with an <code>items</code>, <code>data</code>, <code>animals</code>, <code>adoptables</code> or <code>adoptions</code> array.</div>';
    self::form_end();
    echo '</div>';

    self::form_start('global');
    echo '<div class="ss-suite-card"><h2>Global styling</h2><table class="form-table">';
    foreach (['brand_color'=>'Brand colour','background_color'=>'Background colour','modal_divider_color'=>'Modal divider colour','text_primary_color'=>'Primary text colour','text_muted_color'=>'Muted text colour'] as $k=>$label){ ob_start(); self::colour_input('global',$k,$s['global'][$k]); self::row($label, ob_get_clean()); }
    ob_start(); self::number_input('global','paw_opacity',$s['global']['paw_opacity'],0,0.25,0.01); self::row('Paw print opacity', ob_get_clean());
    ob_start(); self::number_input('global','paw_count',$s['global']['paw_count'],0,80); self::row('Paw print count', ob_get_clean());
    ob_start(); self::text_input('global','font_family',$s['global']['font_family']); self::row('Font family', ob_get_clean());
    ob_start(); self::number_input('global','font_scale_percent',$s['global']['font_scale_percent'],50,200); self::row('Global font scale %', ob_get_clean());
    echo '</table>';
    self::form_end();
    echo '</div>';

    echo '<div class="ss-suite-card"><h2>Reset to baked defaults</h2><p class="description">This resets the suite settings to the baked defaults and re-syncs the three UI modules.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
    wp_nonce_field('straysafe_ui_suite_reset_defaults');
    echo '<input type="hidden" name="action" value="straysafe_ui_suite_reset_defaults"><p><button type="submit" class="button">Reset to baked defaults</button></p></form>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">'; wp_nonce_field('straysafe_ui_suite_save_current_defaults'); echo '<input type="hidden" name="action" value="straysafe_ui_suite_save_current_defaults"><p><button type="submit" class="button button-primary">Save current settings as defaults</button></p></form></div>';

    echo '<div class="ss-suite-card" style="grid-column:1/-1;"><h2>Export / Import</h2><div class="ss-suite-actions">';
    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; wp_nonce_field('straysafe_ui_suite_export'); echo '<input type="hidden" name="action" value="straysafe_ui_suite_export" />'; submit_button('Export settings','secondary','submit',false); echo '</form>';
    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" enctype="multipart/form-data">'; wp_nonce_field('straysafe_ui_suite_import'); echo '<input type="hidden" name="action" value="straysafe_ui_suite_import" /><input type="file" name="import_file" accept="application/json" /> '; submit_button('Import settings','secondary','submit',false); echo '</form>';
    $packs = get_option('straysafe_ui_suite_setting_packs', []); if (!is_array($packs)) $packs = []; echo '<hr><h3>Named setting packs</h3><div class="ss-suite-actions">'; echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; wp_nonce_field('straysafe_ui_suite_save_pack'); echo '<input type="hidden" name="action" value="straysafe_ui_suite_save_pack" /><input type="text" name="pack_name" placeholder="Pack name" class="regular-text" /> '; submit_button('Save current settings as pack','secondary','submit',false); echo '</form>'; echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">'; wp_nonce_field('straysafe_ui_suite_load_pack'); echo '<input type="hidden" name="action" value="straysafe_ui_suite_load_pack" /><select name="pack_id">'; foreach($packs as $pack_id=>$pack){ printf('<option value="%s">%s</option>', esc_attr($pack_id), esc_html($pack['name'] ?? $pack_id)); } echo '</select> '; submit_button('Load selected pack','secondary','submit',false); echo '</form></div><p class="description">Export includes suite settings and the three UI option sets. Import restores them on this site. Settings exports from newer suite builds are accepted where keys are compatible.</p></div>';
    echo '</div>';
  }


  private static function subtab_nav($tab, $items) {
    $current = sanitize_key($_GET['subtab'] ?? array_key_first($items));
    echo '<div class="ss-suite-subnav">';
    foreach ($items as $key => $label) {
      $url = add_query_arg(['page'=>'straysafe-ui-suite','tab'=>$tab,'subtab'=>$key], admin_url('options-general.php'));
      printf('<a class="%s" href="%s">%s</a>', $current === $key ? 'active' : '', esc_url($url), esc_html($label));
    }
    echo '</div>';
    return $current;
  }

  private static function render_typography_table($section,$rows,$o) {
    echo '<table class="ss-suite-table"><thead><tr><th>Text</th><th>Mobile</th><th>Tablet</th><th>PC</th><th>Weight</th></tr></thead><tbody>';
    foreach ($rows as $slug=>$label) {
      echo '<tr><td>'.esc_html($label).'</td><td>'; self::number_input($section,'fs_'.$slug.'_mobile',$o['fs_'.$slug.'_mobile'],10,80); echo '</td><td>'; self::number_input($section,'fs_'.$slug.'_tablet',$o['fs_'.$slug.'_tablet'],10,80); echo '</td><td>'; self::number_input($section,'fs_'.$slug.'_desktop',$o['fs_'.$slug.'_desktop'],10,80); echo '</td><td>';
      $fw='fw_'.$slug; if (isset($o[$fw])) self::number_input($section,$fw,$o[$fw],100,900,100); else echo '—';
      echo '</td></tr>';
    }
    echo '</tbody></table>';
  }

  private static function render_adoptables_tab($o, $g) {
    self::form_start('adoptables');
    $items = [
      'design'=>'Design',
      'text'=>'Text',
      'responsive'=>'Responsive',
      'typography'=>'Typography',
      'modal'=>'Modal',
      'labels'=>'Reservation labels',
      'sharing'=>'Sharing & apply',
      'filters'=>'Filters & extras',
      'layout'=>'Layout builder',
    ];
    $sub = self::subtab_nav('adoptables', $items);
    echo '<div class="ss-suite-grid">';

    echo '<div class="ss-suite-card ss-suite-subsection '.($sub==='design'?'active':'').'" data-subtab="design"><h2>Design</h2><table class="form-table">';
    foreach (['brand_color'=>'Brand colour','background_color'=>'Background colour','modal_divider_color'=>'Modal divider colour','card_border_color'=>'Card border colour'] as $k=>$label){ ob_start(); self::colour_input('adoptables',$k,$o[$k]); self::row($label, ob_get_clean()); }
    foreach ([['paw_opacity','Paw print opacity',0,0.25,0.01],['paw_count','Paw print count',0,80,1],['font_family','Font family',0,0,0],['card_padding','Card padding (px)',0,120,1],['card_radius','Card corner radius (px)',0,120,1],['card_border_weight','Card border weight (px)',0,20,1]] as $r){ ob_start(); if($r[0]==='font_family') self::text_input('adoptables',$r[0],$o[$r[0]]); else self::number_input('adoptables',$r[0],$o[$r[0]],$r[2],$r[3],$r[4]); self::row($r[1], ob_get_clean()); }
    ob_start(); self::checkbox_input('adoptables','card_border_enabled',$o['card_border_enabled'],'Show card border'); self::row('Card border', ob_get_clean());
    ob_start(); self::select_input('adoptables','display_style',$o['display_style'] ?? 'classic',['classic'=>'Classic','compact'=>'Compact','list'=>'List']); self::row('Display style', ob_get_clean());
    echo '</table></div>';

    echo '<div class="ss-suite-card ss-suite-subsection '.($sub==='text'?'active':'').'" data-subtab="text"><h2>Text</h2><table class="form-table">';
    foreach (['title_text'=>'Title text','subtitle_text'=>'Subtitle text','footer_text'=>'Footer text','loading_status_text'=>'Loading status text','loading_page_label_text'=>'Loading page label text','tips_text'=>'Tips text (modal)'] as $k=>$label){ ob_start(); if($k==='footer_text') self::textarea_input('adoptables',$k,$o[$k],3); else self::text_input('adoptables',$k,$o[$k]); self::row($label, ob_get_clean()); }
    echo '</table></div>';

    echo '<div class="ss-suite-card ss-suite-subsection '.($sub==='responsive'?'active':'').'" data-subtab="responsive"><h2>Responsive</h2><table class="form-table">';
    foreach ([['Mobile columns / rows','cols_mobile','rows_mobile'],['Tablet columns / rows','cols_tablet','rows_tablet'],['PC columns / rows','cols_desktop','rows_desktop']] as $r){ ob_start(); echo '<div class="ss-suite-inline">'; self::number_input('adoptables',$r[1],$o[$r[1]],1,12); self::number_input('adoptables',$r[2],$o[$r[2]],1,12); echo '</div>'; self::row($r[0], ob_get_clean()); }
    foreach ([['Mobile gap X / Y','gap_x_mobile','gap_y_mobile'],['Tablet gap X / Y','gap_x_tablet','gap_y_tablet'],['PC gap X / Y','gap_x_desktop','gap_y_desktop']] as $r){ ob_start(); echo '<div class="ss-suite-inline">'; self::number_input('adoptables',$r[1],$o[$r[1]],0,200); self::number_input('adoptables',$r[2],$o[$r[2]],0,200); echo '</div>'; self::row($r[0], ob_get_clean()); }
    ob_start(); echo '<div class="ss-suite-inline">'; self::number_input('adoptables','card_scale_mobile',$o['card_scale_mobile'],50,200); self::number_input('adoptables','card_scale_tablet',$o['card_scale_tablet'],50,200); self::number_input('adoptables','card_scale_desktop',$o['card_scale_desktop'],50,200); echo '</div>'; self::row('Card scale M / T / PC', ob_get_clean());
    ob_start(); self::checkbox_input('adoptables','show_top_navigation',$o['show_top_navigation'] ?? 1,'Show the upper previous/next navigation above the cards'); self::row('Upper navigation', ob_get_clean());
    echo '</table></div>';

    echo '<div class="ss-suite-card ss-suite-subsection '.($sub==='typography'?'active':'').'" data-subtab="typography"><h2>Typography</h2>';
    self::render_typography_table('adoptables', ['heading'=>'Heading','subheading'=>'Subheading','footer'=>'Footer','page_label'=>'Page label','modal_name'=>'Modal name','modal_meta'=>'Modal meta','modal_desc'=>'Modal description','tips'=>'Tips'], $o);
    echo '</div>';

    echo '<div class="ss-suite-card ss-suite-subsection '.($sub==='modal'?'active':'').'" data-subtab="modal"><h2>Modal</h2><table class="form-table">';
    foreach ([['modal_max_width','Modal max width (px)',320,1600],['modal_divider_thickness','Modal divider thickness (px)',0,100],['modal_divider_radius','Modal divider shape radius (px)',0,999]] as $r){ ob_start(); self::number_input('adoptables',$r[0],$o[$r[0]],$r[2],$r[3]); self::row($r[1], ob_get_clean()); }
    ob_start(); self::checkbox_input('adoptables','enable_modals',$o['enable_modals'] ?? 1,'Enable adoptable animal modals'); self::row('Adoptable modals', ob_get_clean());
    ob_start(); self::textarea_input('adoptables','modal_global_text',$o['modal_global_text'] ?? '',6); self::row('Modal global text', ob_get_clean());
    echo '</table></div>';

    echo '<div class="ss-suite-card ss-suite-subsection '.($sub==='labels'?'active':'').'" data-subtab="labels"><h2>Reservation labels</h2><table class="form-table">';
    ob_start(); self::checkbox_input('adoptables','show_reservation_label',$o['show_reservation_label'],'Show reservation label on cards and modal'); self::row('Show reservation label', ob_get_clean());
    ob_start(); self::checkbox_input('adoptables','show_pending_reservation_label',$o['show_pending_reservation_label'] ?? 1,'Show Pending Adoption labels'); self::row('Pending Adoption labels', ob_get_clean());
    ob_start(); self::checkbox_input('adoptables','show_other_reservation_label',$o['show_other_reservation_label'] ?? 1,'Show other active reservation labels'); self::row('Other reservation labels', ob_get_clean());
    foreach (['reservation_pending_label'=>'Pending Adoption label text','reservation_active_label'=>'Other active reservation label text'] as $k=>$label){ ob_start(); self::text_input('adoptables',$k,$o[$k]); self::row($label, ob_get_clean()); }
    ob_start(); self::select_input('adoptables','reservation_label_halign',$o['reservation_label_halign'],['left'=>'Left','center'=>'Center','right'=>'Right']); self::row('Reservation label horizontal alignment', ob_get_clean());
    ob_start(); self::select_input('adoptables','reservation_label_valign',$o['reservation_label_valign'],['top'=>'Top','bottom'=>'Bottom']); self::row('Reservation label vertical alignment', ob_get_clean());
    echo '</table></div>';

    echo '<div class="ss-suite-card ss-suite-subsection '.($sub==='sharing'?'active':'').'" data-subtab="sharing"><h2>Sharing & apply</h2><table class="form-table">';
    foreach (['share_button_text'=>'Share button text','share_copied_text'=>'Share copied text','apply_button_text'=>'Apply button text','apply_form_shortcode'=>'Form shortcode tag','modal_contact_url'=>'Contact page URL'] as $k=>$label){ ob_start(); self::text_input('adoptables',$k,$o[$k] ?? ''); self::row($label, ob_get_clean()); }
    ob_start(); self::checkbox_input('adoptables','enable_deep_links',$o['enable_deep_links'] ?? 1,'Enable direct links and sharing to each cat modal'); self::row('Deep links and share', ob_get_clean());
    ob_start(); self::checkbox_input('adoptables','enable_apply_button',$o['enable_apply_button'] ?? 1,'Show Apply button in the modal'); self::row('Apply button', ob_get_clean());
    echo '</table></div>';

    echo '<div class="ss-suite-card ss-suite-subsection '.($sub==='filters'?'active':'').'" data-subtab="filters"><h2>Filters & extras</h2><table class="form-table">';
    ob_start(); self::checkbox_input('adoptables','enable_filters',$o['enable_filters'] ?? 1,'Show filter controls'); self::row('Enable filters', ob_get_clean());
    foreach (['enable_filter_age'=>'Age','enable_filter_sex'=>'Sex','enable_filter_breed'=>'Breed','enable_exclude_pending_filter'=>'Hide pending adoption','enable_modal_slideshow_controls'=>'Enable modal slideshow controls','enable_favourites'=>'Enable favourites','detect_bonded_from_description'=>'Detect bonded from description','detect_indoor_only_from_description'=>'Detect indoor only from description'] as $k=>$label){ ob_start(); self::checkbox_input('adoptables',$k,$o[$k] ?? 0,$label); self::row($label, ob_get_clean()); }
    foreach (['filter_age_label'=>'Age filter label','filter_sex_label'=>'Sex filter label','filter_breed_label'=>'Breed filter label','filter_exclude_pending_label'=>'Hide pending label','favourites_label_text'=>'Favourites label','show_only_favourites_label'=>'Show favourites label','compare_button_text'=>'Compare button text','bonded_label_text'=>'Bonded badge label','indoor_only_label_text'=>'Indoor only badge label','fallback_description'=>'Fallback description'] as $k=>$label){ ob_start(); if($k==='fallback_description') self::textarea_input('adoptables',$k,$o[$k] ?? '',3); else self::text_input('adoptables',$k,$o[$k] ?? ''); self::row($label, ob_get_clean()); }
    foreach (['bonded_label_bg_color'=>'Bonded badge background','bonded_label_text_color'=>'Bonded badge text','indoor_only_label_bg_color'=>'Indoor badge background','indoor_only_label_text_color'=>'Indoor badge text'] as $k=>$label){ ob_start(); self::colour_input('adoptables',$k,$o[$k] ?? '#ffffff'); self::row($label, ob_get_clean()); }
    ob_start(); self::select_input('adoptables','favourite_button_position',$o['favourite_button_position'] ?? 'top_left',['top_left'=>'Top left','top_right'=>'Top right','bottom_left'=>'Bottom left','bottom_right'=>'Bottom right','hidden'=>'Hidden']); self::row('Favourite button position', ob_get_clean());
    echo '</table></div>';

    echo '<div class="ss-suite-card ss-suite-subsection '.($sub==='layout'?'active':'').'" data-subtab="layout"><h2>Layout builder</h2><p class="description">Use the dedicated Layout builder tab for drag and drop ordering. This shortcut keeps Adoptables settings tidy.</p><p><a class="button button-secondary" href="'.esc_url(add_query_arg(['page'=>'straysafe-ui-suite','tab'=>'layout'], admin_url('options-general.php'))).'">Open Layout builder</a></p></div>';

    echo '</div>';
    self::form_end();
  }

  private static function render_adopted_tab($o, $g) {
    self::form_start('adopted');
    $sub = self::subtab_nav('adopted', ['design'=>'Design','text'=>'Text','responsive'=>'Responsive','typography'=>'Typography','modal'=>'Modal','layout'=>'Layout builder']);
    echo '<div class="ss-suite-grid">';

    if($sub==='design') {
      echo '<div class="ss-suite-card" style="grid-column:1/-1;"><h2>Design</h2><table class="form-table">';
      foreach (['brand_color'=>'Brand colour','background_color'=>'Background colour','text_primary_color'=>'Primary text colour','text_muted_color'=>'Muted text colour','card_border_color'=>'Card border colour'] as $k=>$label){ ob_start(); self::colour_input('adopted',$k,$o[$k]); self::row($label, ob_get_clean()); }
      foreach ([['paw_opacity','Paw print opacity',0,0.25,0.01],['paw_count','Paw print count',0,80,1],['font_family','Font family',0,0,0],['card_border_weight','Card border weight (px)',0,20,1]] as $r){ ob_start(); if($r[0]==='font_family') self::text_input('adopted',$r[0],$o[$r[0]]); else self::number_input('adopted',$r[0],$o[$r[0]],$r[2],$r[3],$r[4]); self::row($r[1], ob_get_clean()); }
      ob_start(); self::checkbox_input('adopted','card_border_enabled',$o['card_border_enabled'],'Show card border'); self::row('Card border', ob_get_clean());
      echo '</table></div>';
    } elseif($sub==='text') {
      echo '<div class="ss-suite-card" style="grid-column:1/-1;"><h2>Text</h2><table class="form-table">';
      foreach (['title_text'=>'Title text','subtitle_text'=>'Subtitle text','footer_text'=>'Footer text'] as $k=>$label){ ob_start(); if($k==='footer_text') self::textarea_input('adopted',$k,$o[$k],3); else self::text_input('adopted',$k,$o[$k]); self::row($label, ob_get_clean()); }
      echo '</table></div>';
    } elseif($sub==='responsive') {
      echo '<div class="ss-suite-card" style="grid-column:1/-1;"><h2>Responsive</h2><table class="form-table">';
      foreach ([['Mobile columns / rows','cols_mobile','rows_mobile'],['Tablet columns / rows','cols_tablet','rows_tablet'],['PC columns / rows','cols_desktop','rows_desktop']] as $r){ ob_start(); echo '<div class="ss-suite-inline">'; self::number_input('adopted',$r[1],$o[$r[1]],1,12); self::number_input('adopted',$r[2],$o[$r[2]],1,12); echo '</div>'; self::row($r[0], ob_get_clean()); }
      ob_start(); echo '<div class="ss-suite-inline">'; self::number_input('adopted','card_scale_mobile',$o['card_scale_mobile'],50,200); self::number_input('adopted','card_scale_tablet',$o['card_scale_tablet'],50,200); self::number_input('adopted','card_scale_desktop',$o['card_scale_desktop'],50,200); echo '</div>'; self::row('Card size M / T / PC', ob_get_clean());
      ob_start(); echo '<div class="ss-suite-inline">'; self::number_input('adopted','card_radius',$o['card_radius'],0,200); self::number_input('adopted','card_padding',$o['card_padding'],0,200); self::number_input('adopted','button_radius',$o['button_radius'],0,200); echo '</div>'; self::row('Card radius / padding / button radius', ob_get_clean());
      ob_start(); self::number_input('adopted','min_year',$o['min_year'],2000,3000); self::row('Minimum year in dropdown', ob_get_clean());
      ob_start(); self::checkbox_input('adopted','show_top_navigation',$o['show_top_navigation'] ?? 1,'Show the upper previous/next navigation above the cards'); self::row('Upper navigation', ob_get_clean());
      echo '</table></div>';
    } elseif($sub==='typography') {
      echo '<div class="ss-suite-card" style="grid-column:1/-1;"><h2>Typography</h2>';
      self::render_typography_table('adopted', ['heading'=>'Heading','subheading'=>'Subheading','footer'=>'Footer','page_label'=>'Page label','card_name'=>'Card name','card_meta'=>'Card meta','badge'=>'Badge'], $o);
      echo '</div>';
    } elseif($sub==='modal') {
      echo '<div class="ss-suite-card" style="grid-column:1/-1;"><h2>Modal</h2><table class="form-table">';
      ob_start(); self::checkbox_input('adopted','enable_modals',$o['enable_modals'] ?? 1,'Enable adopted animal modals'); self::row('Adopted modals', ob_get_clean());
      ob_start(); self::checkbox_input('adopted','enable_deep_links',$o['enable_deep_links'] ?? 1,'Enable direct links and sharing to each adopted cat modal'); self::row('Deep links and share', ob_get_clean());
      foreach (['share_button_text'=>'Share button text','share_copied_text'=>'Share copied text'] as $k=>$label){ ob_start(); self::text_input('adopted',$k,$o[$k] ?? ''); self::row($label, ob_get_clean()); }
      ob_start(); self::textarea_input('adopted','modal_global_text',$o['modal_global_text'] ?? '',5); self::row('Modal text below story', ob_get_clean() . '<p class="description">Shown below the story section in adopted modals.</p>');
      ob_start(); self::checkbox_input('adopted','adoptables_cta_enabled',$o['adoptables_cta_enabled'] ?? 0,'Show an adoptables link section in adopted modals'); self::row('Adoptables link section', ob_get_clean());
      ob_start(); self::text_input('adopted','adoptables_cta_text',$o['adoptables_cta_text'] ?? ''); self::row('Adoptables link text', ob_get_clean());
      ob_start(); self::text_input('adopted','adoptables_cta_button_text',$o['adoptables_cta_button_text'] ?? ''); self::row('Adoptables button text', ob_get_clean());
      self::row('Adoptables page URL', '<input type="url" name="' . esc_attr(self::field_name('adopted','adoptables_cta_url')) . '" value="' . esc_attr($o['adoptables_cta_url'] ?? '') . '" class="regular-text code" placeholder="' . esc_attr(home_url('/adopt/')) . '" />');
      ob_start(); self::number_input('adopted','modal_max_width',$o['modal_max_width'] ?? 896,320,1600); self::row('Modal max width (px)', ob_get_clean());
      ob_start(); self::select_input('adopted','date_label_halign',$o['date_label_halign'],['left'=>'Left','right'=>'Right']); self::row('Date label horizontal alignment', ob_get_clean());
      ob_start(); self::select_input('adopted','date_label_valign',$o['date_label_valign'],['top'=>'Top','bottom'=>'Bottom']); self::row('Date label vertical alignment', ob_get_clean());
      echo '</table></div>';
    } else {
      echo '<div class="ss-suite-card" style="grid-column:1/-1;"><h2>Layout builder</h2><p class="description">Universal layout builder support for Adopted is now enabled as groundwork. The adopted modal uses the same ordering pipeline as adoptables.</p><p><a class="button button-secondary" href="'.esc_url(add_query_arg(['page'=>'straysafe-ui-suite','tab'=>'layout','subtab'=>'adopted'], admin_url('options-general.php'))).'">Open adopted layout builder</a></p></div>';
    }

    echo '</div>';
    self::form_end();
  }

  private static function render_stats_tab($o, $g) {
    self::form_start('stats');
    $sub = self::subtab_nav('stats', ['design'=>'Design','text'=>'Text','responsive'=>'Responsive','typography'=>'Typography','cards'=>'Cards','layout'=>'Layout builder']);
    echo '<div class="ss-suite-grid">';

    if($sub==='design') {
      echo '<div class="ss-suite-card" style="grid-column:1/-1;"><h2>Design</h2><table class="form-table">';
      foreach (['brand_color'=>'Brand colour','background_color'=>'Background colour','card_border_color'=>'Card border colour'] as $k=>$label){ ob_start(); self::colour_input('stats',$k,$o[$k]); self::row($label, ob_get_clean()); }
      foreach ([['paw_opacity','Paw print opacity',0,0.25,0.01],['paw_count','Paw print count',0,80,1],['font_family','Font family',0,0,0],['card_radius','Card corner radius (px)',0,200,1],['card_padding','Card padding (px)',0,200,1],['card_border_weight','Card border weight (px)',0,20,1]] as $r){ ob_start(); if($r[0]==='font_family') self::text_input('stats',$r[0],$o[$r[0]]); else self::number_input('stats',$r[0],$o[$r[0]],$r[2],$r[3],$r[4]); self::row($r[1], ob_get_clean()); }
      ob_start(); self::checkbox_input('stats','card_border_enabled',$o['card_border_enabled'],'Show card border'); self::row('Card border', ob_get_clean());
      ob_start(); self::select_input('stats','layout_mode',$o['layout_mode'],['grid'=>'Grid','one_row'=>'One row on tablet / PC']); self::row('Layout mode', ob_get_clean());
      echo '</table></div>';
    } elseif($sub==='text') {
      echo '<div class="ss-suite-card" style="grid-column:1/-1;"><h2>Text</h2><table class="form-table">';
      foreach (['title_text'=>'Title text','year_label_prefix'=>'Year label prefix','min_year'=>'Minimum year','footer_text'=>'Footer text'] as $k=>$label){ ob_start(); if($k==='footer_text') self::textarea_input('stats',$k,$o[$k],3); elseif($k==='min_year') self::number_input('stats',$k,$o[$k],2000,3000); else self::text_input('stats',$k,$o[$k]); self::row($label, ob_get_clean()); }
      echo '</table></div>';
    } elseif($sub==='responsive') {
      echo '<div class="ss-suite-card" style="grid-column:1/-1;"><h2>Responsive</h2><table class="form-table">';
      foreach ([['Mobile columns / rows','cols_mobile','rows_mobile'],['Tablet columns / rows','cols_tablet','rows_tablet'],['PC columns / rows','cols_desktop','rows_desktop']] as $r){ ob_start(); echo '<div class="ss-suite-inline">'; self::number_input('stats',$r[1],$o[$r[1]],1,12); self::number_input('stats',$r[2],$o[$r[2]],1,12); echo '</div>'; self::row($r[0], ob_get_clean()); }
      foreach ([['Card width M / T / PC','card_w_mobile','card_w_tablet','card_w_desktop'],['Card height M / T / PC','card_h_mobile','card_h_tablet','card_h_desktop']] as $r){ ob_start(); echo '<div class="ss-suite-inline">'; self::number_input('stats',$r[1],$o[$r[1]],0,1600); self::number_input('stats',$r[2],$o[$r[2]],0,1600); self::number_input('stats',$r[3],$o[$r[3]],0,1600); echo '</div>'; self::row($r[0], ob_get_clean()); }
      echo '</table></div>';
    } elseif($sub==='typography') {
      echo '<div class="ss-suite-card" style="grid-column:1/-1;"><h2>Typography</h2><table class="ss-suite-table"><thead><tr><th>Text</th><th>Mobile</th><th>Tablet</th><th>PC</th></tr></thead><tbody>';
      foreach (['heading'=>'Heading','subheading'=>'Subheading','paragraph'=>'Paragraph'] as $slug=>$label){ echo '<tr><td>'.esc_html($label).'</td><td>'; self::number_input('stats','fs_'.$slug.'_mobile',$o['fs_'.$slug.'_mobile'],10,80); echo '</td><td>'; self::number_input('stats','fs_'.$slug.'_tablet',$o['fs_'.$slug.'_tablet'],10,80); echo '</td><td>'; self::number_input('stats','fs_'.$slug.'_desktop',$o['fs_'.$slug.'_desktop'],10,80); echo '</td></tr>'; }
      echo '</tbody></table></div>';
    } elseif($sub==='cards') {
      echo '<div class="ss-suite-card" style="grid-column:1/-1;"><h2>Cards</h2><table class="form-table">'; ob_start(); self::textarea_input('stats','card_order',$o['card_order'],7); self::row('Card order', ob_get_clean()); echo '</table><table class="ss-suite-table"><thead><tr><th>Card</th><th>Heading</th><th>Caption</th><th>Icon</th></tr></thead><tbody>';
      foreach (['brought','adopted','vaccinated','neutered','chipped','in_care'] as $card){ echo '<tr><td><code>'.esc_html($card).'</code></td><td>'; self::text_input('stats','label_'.$card,$o['label_'.$card]); echo '</td><td>'; self::text_input('stats','caption_'.$card,$o['caption_'.$card]); echo '</td><td>'; self::select_input('stats','icon_'.$card,$o['icon_'.$card], self::icon_options()); echo '</td></tr>'; }
      echo '</tbody></table></div>';
    } else {
      echo '<div class="ss-suite-card" style="grid-column:1/-1;"><h2>Layout builder</h2><p class="description">Statistics cards now share the universal card sizing and text sizing framework. Drag and drop expansion can be added next.</p></div>';
    }

    echo '</div>';
    self::form_end();
  }

  private static function render_widgets_tab($settings) {
    $w = $settings['widgets'];
    self::form_start('widgets');
    $sub = self::subtab_nav('widgets', ['featured'=>'Featured animal','stories'=>'Adoption stories','design'=>'Design','responsive'=>'Responsive']);
    echo '<div class="ss-suite-grid">';
    if($sub==='featured') {
      echo '<div class="ss-suite-card"><h2>Featured animal</h2><table class="form-table">';
      ob_start(); self::checkbox_input('widgets','featured_enabled',$w['featured_enabled'],'Enable featured animal shortcode'); self::row('Enable', ob_get_clean());
      foreach (['featured_shortcode'=>'Shortcode','featured_title_text'=>'Title text','featured_subtitle_text'=>'Subtitle text','featured_button_text'=>'Button text','featured_manual_id'=>'Manual animal ID'] as $k=>$label){ ob_start(); self::text_input('widgets',$k,$w[$k]); self::row($label, ob_get_clean()); }
      ob_start(); self::select_input('widgets','featured_mode',$w['featured_mode'],['random'=>'Random','newest'=>'Newest intake','manual'=>'Manual ID']); self::row('Featured mode', ob_get_clean());
      echo '</table></div>';
    } elseif($sub==='stories') {
      echo '<div class="ss-suite-card"><h2>Adoption stories</h2><table class="form-table">';
      ob_start(); self::checkbox_input('widgets','stories_enabled',$w['stories_enabled'],'Enable adoption stories shortcode'); self::row('Enable', ob_get_clean());
      foreach (['stories_shortcode'=>'Shortcode','stories_title_text'=>'Title text'] as $k=>$label){ ob_start(); self::text_input('widgets',$k,$w[$k]); self::row($label, ob_get_clean()); }
      ob_start(); self::number_input('widgets','stories_count',$w['stories_count'],1,12); self::row('Story count', ob_get_clean());
      ob_start(); self::select_input('widgets','stories_year_mode',$w['stories_year_mode'],['current'=>'Current year only','all'=>'All years']); self::row('Date range', ob_get_clean());
      echo '</table></div>';
    } elseif($sub==='design') {
      echo '<div class="ss-suite-card"><h2>Widget design</h2><p class="description">Widgets now inherit the same card, text and responsive framework as the main UIs. A fuller widget builder can be added next.</p></div>';
    } elseif($sub==='responsive') {
      echo '<div class="ss-suite-card"><h2>Widget responsive settings</h2><p class="description">Featured animal and adoption stories previews below use the same renderer path as live embeds.</p></div>';
    } else {
      echo '<div class="ss-suite-card"><h2>Widget previews removed</h2><p class="description">Live previews have been removed because they were not reliably matching the embedded site output. Use staging pages to verify widgets.</p></div>';
    }
    echo '</div>';
    self::form_end();
  }

  private static function render_quiz_tab($settings) {
    $q = $settings['quiz'];
    self::form_start('quiz');
    $sub = self::subtab_nav('quiz', ['settings'=>'Settings','questions'=>'Questions','ai'=>'AI scoring']);
    echo '<div class="ss-suite-grid">';
    if($sub==='settings') {
      echo '<div class="ss-suite-card"><h2>Quiz settings</h2><table class="form-table">';
      ob_start(); self::checkbox_input('quiz','quiz_enabled',$q['quiz_enabled'],'Enable adoption match quiz shortcode'); self::row('Enable', ob_get_clean());
      foreach (['quiz_shortcode'=>'Shortcode','quiz_title_text'=>'Title text','quiz_intro_text'=>'Intro text','results_title_text'=>'Results heading','results_empty_text'=>'No results text'] as $k=>$label){ ob_start(); self::text_input('quiz',$k,$q[$k]); self::row($label, ob_get_clean()); }
      echo '</table></div>';
    } elseif($sub==='questions') {
      echo '<div class="ss-suite-card"><h2>Questions</h2><table class="form-table">';
      foreach (['q1_text'=>'Question 1 text','q2_text'=>'Question 2 text','q3_text'=>'Question 3 text'] as $k=>$label){ ob_start(); self::text_input('quiz',$k,$q[$k]); self::row($label, ob_get_clean()); }
      ob_start(); self::textarea_input('quiz','age_categories',$q['age_categories'] ?? '',5); self::row('Age categories', ob_get_clean());
      ob_start(); echo '<p class="description">One category per line in the format <code>Label|min|max</code> using years. Leave max blank for no upper limit.</p>'; self::row('Age category format', ob_get_clean());
      foreach (['q2_female_label'=>'Female label','q2_male_label'=>'Male label','q2_either_label'=>'Question 2 no preference label','q3_yes_label'=>'Indoor only yes label','q3_no_label'=>'Question 3 no preference label'] as $k=>$label){ ob_start(); self::text_input('quiz',$k,$q[$k]); self::row($label, ob_get_clean()); }
      ob_start(); self::checkbox_input('quiz','q3_hide',$q['q3_hide'],'Hide indoor-only question'); self::row('Question 3 visibility', ob_get_clean());
      echo '</table></div>';
    } elseif($sub==='ai') {
      echo '<div class="ss-suite-card"><h2>AI adoption scoring</h2><p class="description">AI match scoring is live. Quiz results now use weighted relevance across age, sex, indoor-only preference, bonded-pair preference, and good-with answers.</p></div>';
    } else {
      echo '<div class="ss-suite-card"><h2>Quiz previews removed</h2><p class="description">Live previews have been removed because they were not reliably matching the embedded site output. Test the quiz on a staging page instead.</p></div>';
    }
    echo '</div>';
    self::form_end();
  }

  private static function render_forms_tab($settings) {
    self::form_start('forms'); $sc=$settings['shortcodes']; $items=$settings['forms']['items'];
    echo '<div class="ss-suite-grid"><div class="ss-suite-card"><h2>UI shortcodes</h2><table class="form-table">';
    foreach (['adoptables'=>'Adoptables UI shortcode','adopted'=>'Adopted UI shortcode','statistics'=>'Statistics UI shortcode'] as $k=>$label){ ob_start(); self::text_input('shortcodes',$k,$sc[$k]); echo '<p class="description">Use as <code>['.esc_html($sc[$k]).']</code></p>'; self::row($label, ob_get_clean()); }
    echo '</table></div><div class="ss-suite-card" style="grid-column:span 2;"><h2>Forms</h2><table class="form-table">'; ob_start(); self::text_input('forms','account',$settings['forms']['account']); self::row('Shelter Manager account', ob_get_clean()); echo '</table><table class="ss-suite-table"><thead><tr><th>#</th><th>Shortcode</th><th>Form ID</th><th>Use</th></tr></thead><tbody>';
    for($i=0;$i<10;$i++){ $row=$items[$i] ?? ['shortcode'=>'','form_id'=>'']; $tag=self::sanitize_shortcode_tag($row['shortcode'] ?? ''); echo '<tr><td>'.($i+1).'</td><td><input type="text" name="suite[forms][items]['.$i.'][shortcode]" value="'.esc_attr($row['shortcode'] ?? '').'" class="regular-text" /></td><td><input type="text" name="suite[forms][items]['.$i.'][form_id]" value="'.esc_attr($row['form_id'] ?? '').'" class="small-text" /></td><td>'.($tag?'<code>['.esc_html($tag).']</code>':'').'</td></tr>'; }
    echo '</tbody></table></div></div>';
    self::form_end();
  }

  private static function render_layout_tab($settings) {
    self::form_start('layout');
    $sub = self::subtab_nav('layout', ['adoptables'=>'Adoptables','adopted'=>'Adopted','widgets'=>'Widgets']);
    echo '<div class="ss-suite-grid">';
    if ($sub==='adoptables') {
      echo '<div class="ss-suite-card"><h2>Adoptables card order</h2>';
      self::sortable_list(self::field_name('adoptables','builder_card_order'), preg_split('/\R+/', (string)($settings['adoptables']['builder_card_order'] ?? ''), -1, PREG_SPLIT_NO_EMPTY), [
        'image'=>'Image','reservation_badge'=>'Reservation badge','name_meta'=>'Name & meta','breed_line'=>'Breed line','favourite_button'=>'Favourite button'
      ]);
      echo '</div>';
      echo '<div class="ss-suite-card"><h2>Adoptables modal order</h2>';
      self::sortable_list(self::field_name('adoptables','builder_modal_order'), preg_split('/\R+/', (string)($settings['adoptables']['builder_modal_order'] ?? ''), -1, PREG_SPLIT_NO_EMPTY), [
        'gallery'=>'Gallery','badges'=>'Badges','info_cards'=>'Info cards','tips'=>'Tips','description'=>'Description','global_text'=>'Global text','contact_footer'=>'Contact footer','custom_buttons'=>'Custom buttons'
      ]);
      echo '</div>';
      echo '<div class="ss-suite-card"><h2>Adoptables header actions</h2>';
      self::sortable_list(self::field_name('adoptables','builder_header_actions'), preg_split('/\R+/', (string)($settings['adoptables']['builder_header_actions'] ?? ''), -1, PREG_SPLIT_NO_EMPTY), [
        'apply'=>'Apply','favourite'=>'Favourite','share'=>'Share','close'=>'Close'
      ]);
      echo '</div>';
    } elseif ($sub==='adopted') {
      echo '<div class="ss-suite-card"><h2>Adopted layout</h2><p class="description">Adopted layout builder groundwork is in place. More drag and drop areas can be added next.</p></div>';
    } else {
      echo '<div class="ss-suite-card"><h2>Widgets layout</h2><p class="description">Widgets layout builder groundwork is in place. Featured and stories widget ordering can be expanded next.</p></div>';
    }
    echo '</div>';
    self::form_end();
  }

  private static function get_proxy_settings($settings = null) {
    if (!is_array($settings)) $settings = self::get_settings();
    $defaults = self::default_settings()['proxy'];
    $proxy = isset($settings['proxy']) && is_array($settings['proxy']) ? array_merge($defaults, $settings['proxy']) : $defaults;
    return $proxy;
  }

  private static function define_proxy_constants_from_settings($settings = null) {
    $proxy = self::get_proxy_settings($settings ?: self::load_saved_settings());
    $pairs = [
      'ASM_BASE_URL' => $proxy['base_url'] ?? '',
      'ASM_ACCOUNT' => $proxy['account'] ?? '',
      'ASM_USERNAME' => $proxy['username'] ?? '',
      'ASM_PASSWORD' => $proxy['password'] ?? '',
    ];
    foreach ($pairs as $name => $value) {
      if (!defined($name) && $value !== '') define($name, $value);
    }
  }

  private static function module_versions() {
    return [
      'suite_core' => STRAYSAFE_SUITE_VERSION,
      'adoptables' => '15',
      'adopted' => '18',
      'statistics' => '11',
      'forms' => '1.0.0',
      'proxy' => '1.3.6',
    ];
  }

  private static function record_version_event($event) {
    $log = get_option(self::LOG_KEY, []);
    if (!is_array($log)) $log = [];
    array_unshift($log, [
      'time' => current_time('mysql'),
      'event' => sanitize_key($event),
      'suite_version' => self::module_versions()['suite_core'],
      'module_versions' => self::module_versions(),
    ]);
    $log = array_slice($log, 0, 25);
    update_option(self::LOG_KEY, $log, false);
  }

  private static function create_snapshot($reason = 'manual') {
    $snapshots = get_option(self::SNAP_KEY, []);
    if (!is_array($snapshots)) $snapshots = [];
    array_unshift($snapshots, [
      'id' => wp_generate_uuid4(),
      'time' => current_time('mysql'),
      'reason' => sanitize_key($reason),
      'suite' => self::exportable_settings(self::get_settings()),
      'legacy' => [
        'adoptables' => get_option('straysafe_adoptables_ui_options', []),
        'adopted' => get_option('straysafe_adopted_ui_options', []),
        'stats' => get_option('straysafe_stats_ui_options', []),
      ],
    ]);
    $snapshots = array_slice($snapshots, 0, 10);
    update_option(self::SNAP_KEY, $snapshots, false);
  }

  private static function get_snapshots() {
    $snapshots = get_option(self::SNAP_KEY, []);
    return is_array($snapshots) ? $snapshots : [];
  }

  public static function handle_restore_snapshot() {
    if (!current_user_can('manage_options')) wp_die('Permission denied.');
    check_admin_referer('straysafe_ui_suite_restore_snapshot');
    $id = sanitize_text_field($_POST['snapshot_id'] ?? '');
    $snapshots = self::get_snapshots();
    foreach ($snapshots as $snapshot) {
      if (($snapshot['id'] ?? '') !== $id) continue;
      self::create_snapshot('pre_restore');
      if (!empty($snapshot['suite']) && is_array($snapshot['suite'])) update_option(self::OPT_KEY, $snapshot['suite'], false);
      if (!empty($snapshot['legacy']['adoptables'])) update_option('straysafe_adoptables_ui_options', $snapshot['legacy']['adoptables']);
      if (!empty($snapshot['legacy']['adopted'])) update_option('straysafe_adopted_ui_options', $snapshot['legacy']['adopted']);
      if (!empty($snapshot['legacy']['stats'])) update_option('straysafe_stats_ui_options', $snapshot['legacy']['stats']);
      self::record_version_event('snapshot_restore');
      wp_safe_redirect(add_query_arg(['page'=>'straysafe-ui-suite','tab'=>'diagnostics','updated'=>'true','ss_msg'=>'Snapshot restored'], admin_url('options-general.php')));
      exit;
    }
    wp_safe_redirect(add_query_arg(['page'=>'straysafe-ui-suite','tab'=>'diagnostics','ss_msg'=>'Snapshot not found'], admin_url('options-general.php')));
    exit;
  }

  public static function handle_delete_snapshot() {
    if (!current_user_can('manage_options')) wp_die('Permission denied.');
    check_admin_referer('straysafe_ui_suite_delete_snapshot');
    $id = sanitize_text_field($_POST['snapshot_id'] ?? '');
    $snapshots = array_values(array_filter(self::get_snapshots(), function($snapshot) use ($id){ return ($snapshot['id'] ?? '') !== $id; }));
    update_option(self::SNAP_KEY, $snapshots, false);
    wp_safe_redirect(add_query_arg(['page'=>'straysafe-ui-suite','tab'=>'diagnostics','updated'=>'true','ss_msg'=>'Snapshot deleted'], admin_url('options-general.php')));
    exit;
  }

  public static function handle_export_module() {
    if (!current_user_can('manage_options')) wp_die('Permission denied.');
    check_admin_referer('straysafe_ui_suite_export_module');
    $module = sanitize_key($_POST['module'] ?? '');
    $settings = self::get_settings();
    $payload = ['module' => $module, 'version' => self::module_versions()[$module] ?? '', 'data' => self::exportable_module_settings($module, $settings[$module] ?? [])];
    nocache_headers();
    header('Content-Type: application/json; charset=' . get_bloginfo('charset'));
    header('Content-Disposition: attachment; filename=straysafe-ui-suite-' . $module . '.json');
    echo wp_json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
  }

  public static function handle_import_module() {
    if (!current_user_can('manage_options')) wp_die('Permission denied.');
    check_admin_referer('straysafe_ui_suite_import_module');
    $module = sanitize_key($_POST['module'] ?? '');
    if (empty($_FILES['import_file']['tmp_name'])) wp_die('No import file uploaded.');
    $data = json_decode(file_get_contents($_FILES['import_file']['tmp_name']), true);
    if (!is_array($data) || ($data['module'] ?? '') !== $module || !is_array($data['data'] ?? null)) wp_die('Invalid module import file.');
    $settings = self::get_settings();
    self::create_snapshot('import_' . $module);
    $settings[$module] = array_replace_recursive(self::default_settings()[$module], $data['data']);
    if ($module === 'proxy') {
      $current = self::get_settings()['proxy'] ?? [];
      foreach (['account','username','password'] as $secret_key) {
        if (empty($settings[$module][$secret_key]) && !empty($current[$secret_key])) $settings[$module][$secret_key] = $current[$secret_key];
      }
    }
    update_option(self::OPT_KEY, $settings, false);
    self::sync_legacy_options($settings);
    wp_safe_redirect(add_query_arg(['page'=>'straysafe-ui-suite','tab'=>'diagnostics','updated'=>'true','ss_msg'=>ucfirst($module).' imported'], admin_url('options-general.php')));
    exit;
  }



  public static function handle_save_pack() {
    if (!current_user_can('manage_options')) wp_die('Permission denied.');
    check_admin_referer('straysafe_ui_suite_save_pack');
    $name = sanitize_text_field($_POST['pack_name'] ?? '');
    if ($name === '') $name = 'Settings pack ' . current_time('Y-m-d H:i');
    $packs = get_option('straysafe_ui_suite_setting_packs', []);
    if (!is_array($packs)) $packs = [];
    $packs[sanitize_title($name)] = ['name'=>$name,'created'=>current_time('mysql'),'suite'=>self::exportable_settings(self::get_settings())];
    update_option('straysafe_ui_suite_setting_packs', $packs, false);
    wp_safe_redirect(add_query_arg(['page'=>'straysafe-ui-suite','tab'=>'global','updated'=>'true','ss_msg'=>'Settings pack saved'], admin_url('options-general.php'))); exit;
  }
  public static function handle_load_pack() {
    if (!current_user_can('manage_options')) wp_die('Permission denied.');
    check_admin_referer('straysafe_ui_suite_load_pack');
    $id = sanitize_key($_POST['pack_id'] ?? '');
    $packs = get_option('straysafe_ui_suite_setting_packs', []);
    if (!is_array($packs) || empty($packs[$id]['suite']) || !is_array($packs[$id]['suite'])) wp_die('Settings pack not found.');
    self::create_snapshot('load_pack');
    $merged = array_replace_recursive(self::default_settings(), $packs[$id]['suite']);
    $existing = self::get_settings();
    if (isset($existing['proxy']) && is_array($existing['proxy'])) foreach (['account','username','password'] as $secret_key) if (empty($merged['proxy'][$secret_key]) && !empty($existing['proxy'][$secret_key])) $merged['proxy'][$secret_key] = $existing['proxy'][$secret_key];
    if (isset($existing['global']) && is_array($existing['global'])) foreach (['custom_api_key','shelterluv_api_key','petpoint_username','petpoint_password'] as $secret_key) if (empty($merged['global'][$secret_key]) && !empty($existing['global'][$secret_key])) $merged['global'][$secret_key] = $existing['global'][$secret_key];
    update_option(self::OPT_KEY, $merged, false); self::sync_legacy_options($merged);
    wp_safe_redirect(add_query_arg(['page'=>'straysafe-ui-suite','tab'=>'global','updated'=>'true','ss_msg'=>'Settings pack loaded'], admin_url('options-general.php'))); exit;
  }

  private static function exportable_settings($settings) {
    if (!is_array($settings)) return [];
    $copy = $settings;
    if (isset($copy['proxy']) && is_array($copy['proxy'])) {
      unset($copy['proxy']['account'], $copy['proxy']['username'], $copy['proxy']['password']);
    }
    if (isset($copy['global']) && is_array($copy['global'])) {
      unset(
        $copy['global']['custom_api_key'],
        $copy['global']['shelterluv_api_key'],
        $copy['global']['petpoint_username'],
        $copy['global']['petpoint_password']
      );
    }
    return $copy;
  }

  private static function exportable_module_settings($module, $data) {
    if (!is_array($data)) return [];
    if ($module === 'proxy') {
      unset($data['account'], $data['username'], $data['password']);
    }
    return $data;
  }

  public static function render_admin_notices() {
    if (!current_user_can('manage_options')) return;
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$screen || strpos((string)$screen->id, 'straysafe-ui-suite') === false) return;
    $settings = self::get_settings();
    $source_status = self::data_source_status($settings);
    if (!empty($source_status['missing'])) {
      echo '<div class="notice notice-warning"><p>' . esc_html($source_status['label']) . ' is not fully configured. Missing: ' . esc_html(implode(', ', $source_status['missing'])) . '. Use the <a href="' . esc_url(add_query_arg(['page'=>'straysafe-ui-suite-setup'], admin_url('options-general.php'))) . '">setup wizard</a> or the relevant settings tab.</p></div>';
    }
  }

  public static function maybe_redirect_to_setup_wizard() {
    if (!current_user_can('manage_options')) return;
    if (!get_option(self::WIZARD_KEY)) return;
    if (wp_doing_ajax()) return;
    $page = sanitize_key($_GET['page'] ?? '');
    if ($page === 'straysafe-ui-suite-setup') return;
    delete_option(self::WIZARD_KEY);
    wp_safe_redirect(add_query_arg(['page'=>'straysafe-ui-suite-setup'], admin_url('options-general.php')));
    exit;
  }

  public static function handle_setup_save() {
    if (!current_user_can('manage_options')) wp_die('Permission denied.');
    check_admin_referer('straysafe_ui_suite_setup_save');
    $settings = self::get_settings();
    $global = wp_unslash($_POST['suite']['global'] ?? []);
    $adoptables = wp_unslash($_POST['suite']['adoptables'] ?? []);
    $adopted = wp_unslash($_POST['suite']['adopted'] ?? []);
    $quiz = wp_unslash($_POST['suite']['quiz'] ?? []);
    $pr = wp_unslash($_POST['suite']['proxy'] ?? []);
    $source = sanitize_key($global['data_source'] ?? ($settings['global']['data_source'] ?? 'asm'));
    $settings['global']['data_source'] = in_array($source, ['asm','custom_api'], true) ? $source : 'asm';
    $settings['global']['custom_api_url'] = esc_url_raw($global['custom_api_url'] ?? ($settings['global']['custom_api_url'] ?? ''));
    $settings['global']['custom_api_key'] = sanitize_text_field((string)($global['custom_api_key'] ?? ($settings['global']['custom_api_key'] ?? '')));
    $settings['global']['custom_api_auth_header'] = preg_replace('/[^A-Za-z0-9\-]/', '', (string)($global['custom_api_auth_header'] ?? ($settings['global']['custom_api_auth_header'] ?? 'X-API-Key')));
    foreach (['custom_api_adoptables_url','custom_api_adoptions_url','custom_api_report_url','custom_api_incare_url','custom_api_image_url'] as $k) $settings['global'][$k] = esc_url_raw($global[$k] ?? ($settings['global'][$k] ?? ''));
    $settings['global']['shelterluv_api_key'] = sanitize_text_field((string)($global['shelterluv_api_key'] ?? ($settings['global']['shelterluv_api_key'] ?? '')));
    $settings['global']['petpoint_username'] = sanitize_text_field((string)($global['petpoint_username'] ?? ($settings['global']['petpoint_username'] ?? '')));
    $settings['global']['petpoint_password'] = sanitize_text_field((string)($global['petpoint_password'] ?? ($settings['global']['petpoint_password'] ?? '')));
    $settings['proxy']['base_url'] = esc_url_raw($pr['base_url'] ?? $settings['proxy']['base_url']);
    $settings['proxy']['account'] = preg_replace('/[^a-zA-Z0-9_\-]/', '', (string)($pr['account'] ?? ''));
    $settings['proxy']['username'] = sanitize_text_field((string)($pr['username'] ?? ''));
    $settings['proxy']['password'] = (string)($pr['password'] ?? '');
    $settings['adoptables']['enable_filters'] = !empty($adoptables['enable_filters']) ? 1 : 0;
    $settings['adoptables']['enable_favourites'] = !empty($adoptables['enable_favourites']) ? 1 : 0;
    $settings['adopted']['enable_modals'] = !empty($adopted['enable_modals']) ? 1 : 0;
    $settings['quiz']['quiz_enabled'] = !empty($quiz['quiz_enabled']) ? 1 : 0;
    update_option(self::OPT_KEY, $settings, false);
    delete_option(self::WIZARD_KEY);
    self::sync_legacy_options($settings);
    self::record_version_event('setup_completed');
    wp_safe_redirect(add_query_arg(['page'=>'straysafe-ui-suite','tab'=>'proxy','updated'=>'true','ss_msg'=>'Setup completed'], admin_url('options-general.php')));
    exit;
  }

  public static function handle_proxy_test() {
    if (!current_user_can('manage_options')) wp_die('Permission denied.');
    check_admin_referer('straysafe_ui_suite_proxy_test');
    $settings = self::get_settings();
    $source = sanitize_key($settings['global']['data_source'] ?? 'asm');
    $msg = 'Proxy test failed';

    if ($source === 'asm') {
      if (function_exists('ss_asm_http_get') && function_exists('ss_asm_user') && function_exists('ss_asm_pass')) {
        $res = ss_asm_http_get(['method'=>'json_adoptable_animals','username'=>ss_asm_user(),'password'=>ss_asm_pass()]);
        if (is_wp_error($res)) {
          $msg = 'Proxy test failed: ' . $res->get_error_message();
          set_transient('straysafe_ui_suite_last_proxy_error', $res->get_error_message(), 3600);
        } else {
          $msg = 'ASM proxy connection successful';
          set_transient('straysafe_ui_suite_last_proxy_error', '', 60);
          set_transient('straysafe_ui_suite_last_proxy_success', current_time('mysql'), 86400);
        }
      }
    } elseif ($source === 'custom_api') {
      $url = $settings['global']['custom_api_adoptables_url'] ?? '';
      if (!$url && !empty($settings['global']['custom_api_url'])) $url = untrailingslashit($settings['global']['custom_api_url']) . '/adoptables';
      if (!$url) {
        $msg = 'Custom API test failed: adoptables endpoint is not configured';
        set_transient('straysafe_ui_suite_last_proxy_error', $msg, 3600);
      } else {
        $headers = ['Accept' => 'application/json'];
        $header_name = preg_replace('/[^A-Za-z0-9\-]/', '', (string)($settings['global']['custom_api_auth_header'] ?? 'X-API-Key'));
        $api_key = (string)($settings['global']['custom_api_key'] ?? '');
        if ($api_key !== '' && $header_name !== '') $headers[$header_name] = $api_key;
        if ($api_key !== '') $url = add_query_arg(['api_key' => $api_key], $url);
        $res = wp_remote_get($url, ['timeout'=>20,'headers'=>$headers]);
        if (is_wp_error($res)) {
          $msg = 'Custom API test failed: ' . $res->get_error_message();
          set_transient('straysafe_ui_suite_last_proxy_error', $res->get_error_message(), 3600);
        } else {
          $code = wp_remote_retrieve_response_code($res);
          $body = wp_remote_retrieve_body($res);
          $data = json_decode($body, true);
          $items = is_array($data) && isset($data['items']) && is_array($data['items']) ? $data['items'] : $data;
          if ($code >= 200 && $code < 300 && is_array($items)) {
            $msg = 'Custom API connection successful';
            set_transient('straysafe_ui_suite_last_proxy_error', '', 60);
            set_transient('straysafe_ui_suite_last_proxy_success', current_time('mysql'), 86400);
          } else {
            $msg = 'Custom API test failed: endpoint did not return a JSON array';
            set_transient('straysafe_ui_suite_last_proxy_error', $msg, 3600);
          }
        }
      }
    } else {
      $msg = ucfirst($source) . ' connector credentials are saved, but the live fetch layer is not implemented in this build.';
      set_transient('straysafe_ui_suite_last_proxy_error', $msg, 3600);
    }
    wp_safe_redirect(add_query_arg(['page'=>'straysafe-ui-suite','tab'=>'proxy','ss_msg'=>$msg], admin_url('options-general.php')));
    exit;
  }

  public static function handle_proxy_clear_cache() {
    if (!current_user_can('manage_options')) wp_die('Permission denied.');
    check_admin_referer('straysafe_ui_suite_proxy_clear_cache');
    global $wpdb;
    $like_patterns = ['_transient_ss_asm_%','_transient_timeout_ss_asm_%','_transient_ss_custom_api_%','_transient_timeout_ss_custom_api_%','_transient_asm_suite_seo_%','_transient_timeout_asm_suite_seo_%'];
    foreach ($like_patterns as $pattern) {
      $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $pattern));
    }
    wp_cache_flush();
    wp_safe_redirect(add_query_arg(['page'=>'straysafe-ui-suite','tab'=>'proxy','ss_msg'=>'Proxy cache cleared'], admin_url('options-general.php')));
    exit;
  }

  private static function credential_source_label() {
    foreach (['ASM_ACCOUNT','ASM_USERNAME','ASM_PASSWORD'] as $const) {
      if (getenv($const) !== false && getenv($const) !== '') return 'Environment';
    }
    foreach (['ASM_ACCOUNT','ASM_USERNAME','ASM_PASSWORD'] as $const) {
      if (defined($const) && constant($const) !== '') return 'Suite / config constant';
    }
    return 'Not configured';
  }

  private static function proxy_status() {
    $last_error = get_transient('straysafe_ui_suite_last_proxy_error');
    $last_success = get_transient('straysafe_ui_suite_last_proxy_success');
    $settings = self::get_settings();
    return [
      'credential_source' => self::credential_source_label(),
      'data_source' => self::data_source_status($settings),
      'last_error' => is_string($last_error) ? $last_error : '',
      'last_success' => is_string($last_success) ? $last_success : '',
      'routes' => [
        rest_url('straysafe/v1/adoptables'),
        rest_url('straysafe/v1/report'),
        rest_url('straysafe/v1/in-care-count'),
        rest_url('straysafe/v1/adoptions'),
        rest_url('straysafe/v1/animal-image'),
      ],
    ];
  }

  private static function analytics_defaults() {
    return [
      'adoptables_modal_open' => 0,
      'adoptables_apply_click' => 0,
      'adopted_modal_open' => 0,
      'favourite_toggle' => 0,
      'featured_widget_click' => 0,
      'stories_widget_load' => 0,
    ];
  }

  private static function get_analytics() {
    $data = get_option(self::ANALYTICS_KEY, []);
    if (!is_array($data)) $data = [];
    return array_merge(self::analytics_defaults(), $data);
  }

  public static function handle_track_event() {
    $event = sanitize_key($_POST['event'] ?? '');
    $allowed = array_keys(self::analytics_defaults());
    if (!$event || !in_array($event, $allowed, true)) {
      wp_send_json_error(['message' => 'Invalid event'], 400);
    }
    $data = self::get_analytics();
    $data[$event] = (int)($data[$event] ?? 0) + 1;
    update_option(self::ANALYTICS_KEY, $data, false);
    wp_send_json_success(['event' => $event, 'count' => $data[$event]]);
  }


  private static function data_source_definitions() {
    return [
      'asm' => [
        'label' => 'ASM / Shelter Manager',
        'summary' => 'Fully supported live data source using the ASM proxy and report endpoints.',
        'state' => 'live',
      ],
      'shelterluv' => [
        'label' => 'Shelterluv',
        'summary' => 'Credentials and source-aware routing are stored, but a live Shelterluv fetch layer is still pending.',
        'state' => 'groundwork',
      ],
      'petpoint' => [
        'label' => 'PetPoint',
        'summary' => 'Credentials and source-aware routing are stored, but a live PetPoint fetch layer is still pending.',
        'state' => 'groundwork',
      ],
      'custom_api' => [
        'label' => 'Custom API',
        'summary' => 'Fully usable live source using your own JSON feed endpoints, optional API key header and source-aware proxy routing.',
        'state' => 'live',
      ],
    ];
  }

  private static function source_runtime_config($settings) {
    $status = self::data_source_status($settings);
    $g = is_array($settings['global'] ?? null) ? $settings['global'] : [];
    $p = is_array($settings['proxy'] ?? null) ? $settings['proxy'] : [];
    $source = $status['key'] ?? 'asm';
    if ($source === 'asm') {
      return [
        'items' => [
          'Base URL' => (string)($p['base_url'] ?? 'https://service.sheltermanager.com/asmservice'),
          'Account' => (string)($p['account'] ?? ''),
          'Username saved' => !empty($p['username']) ? 'Yes' : 'No',
          'Password saved' => !empty($p['password']) ? 'Yes' : 'No',
          'REST routes' => implode(' | ', [rest_url('straysafe/v1/adoptables'), rest_url('straysafe/v1/adoptions'), rest_url('straysafe/v1/report'), rest_url('straysafe/v1/in-care-count'), rest_url('straysafe/v1/animal-image')]),
        ],
        'contract' => 'ASM is the native live connector. The suite normalises ASM records into the standard StraySafe animal shape before the widgets render.',
      ];
    }
    if ($source === 'custom_api') {
      $base = esc_url_raw($g['custom_api_url'] ?? '');
      $endpoint = function($specific, $suffix) use ($g, $base) {
        $url = esc_url_raw($g[$specific] ?? '');
        if ($url !== '') return $url;
        if ($base !== '') return untrailingslashit($base) . $suffix;
        return '';
      };
      $header = preg_replace('/[^A-Za-z0-9\-]/', '', (string)($g['custom_api_auth_header'] ?? 'X-API-Key'));
      return [
        'items' => [
          'Base URL' => $base,
          'Adoptables endpoint' => $endpoint('custom_api_adoptables_url', '/adoptables'),
          'Adoptions endpoint' => $endpoint('custom_api_adoptions_url', '/adoptions'),
          'Report endpoint' => $endpoint('custom_api_report_url', '/report'),
          'In-care endpoint' => $endpoint('custom_api_incare_url', '/in-care-count'),
          'Image endpoint' => $endpoint('custom_api_image_url', '/animal-image'),
          'Auth header' => $header,
          'API key saved' => !empty($g['custom_api_key']) ? 'Yes' : 'No',
        ],
        'contract' => 'Custom API is live. Feed endpoints should return JSON arrays or an items array in the suite-normalised animal shape. AGE_MONTHS and AGE_BAND are supported and will be derived if omitted.',
      ];
    }
    if ($source === 'shelterluv') {
      return [
        'items' => [
          'Base URL' => (string)($g['shelterluv_base_url'] ?? 'https://www.shelterluv.com'),
          'Organisation ID' => (string)($g['shelterluv_org_id'] ?? ''),
          'API key saved' => !empty($g['shelterluv_api_key']) ? 'Yes' : 'No',
          'Animal type' => (string)($g['shelterluv_animal_type'] ?? 'cat'),
          'Statuses' => (string)($g['shelterluv_statuses'] ?? 'adoptable,foster'),
          'Location IDs' => (string)($g['shelterluv_location_ids'] ?? ''),
        ],
        'contract' => 'Shelterluv groundwork is now prepared with enough settings to map a later live connector onto the suite-standard adoptables, adoptions, reports and image pipeline.',
      ];
    }
    return [
      'items' => [
        'Base URL' => (string)($g['petpoint_base_url'] ?? ''),
        'Shelter ID / database' => (string)($g['petpoint_shelter_id'] ?? ''),
        'Username saved' => !empty($g['petpoint_username']) ? 'Yes' : 'No',
        'Password saved' => !empty($g['petpoint_password']) ? 'Yes' : 'No',
        'Location IDs' => (string)($g['petpoint_location_ids'] ?? ''),
        'Species ID' => (string)($g['petpoint_species_id'] ?? '2'),
        'Statuses' => (string)($g['petpoint_statuses'] ?? 'available,foster'),
        'Adopted report ID' => (string)($g['petpoint_adopted_report_id'] ?? ''),
      ],
      'contract' => 'PetPoint groundwork is now prepared with enough settings to map a later live connector and adopted reporting path onto the shared suite data model.',
    ];
  }

  private static function source_contract_reference() {
    return [
      'adoptables' => [
        'required' => ['ID', 'ANIMALNAME'],
        'supported' => ['CODE','ANIMALAGE','AGE_MONTHS','AGE_BAND','SEXNAME','SEX','BREEDNAME','BREEDNAME1','SPECIESID','SPECIESNAME','DAYSONSHELTER','WEBSITEIMAGECOUNT','WEBSITEIMAGES','ANIMALCOMMENTS','WEBSITEMEDIANOTES','DESCRIPTION','ANIMALDESCRIPTION','HASACTIVERESERVE','HASACTIVERESERVENAME','reservation_statuses','reservation_status_counts','reservation_count','has_active_reservation','primary_reservation_status'],
      ],
      'adoptions' => [
        'required' => ['ID', 'ANIMALNAME'],
        'supported' => ['CODE','ANIMALAGE','AGE_MONTHS','AGE_BAND','SEXNAME','SEX','BREEDNAME','BREEDNAME1','SPECIESID','SPECIESNAME','WEBSITEIMAGECOUNT','WEBSITEIMAGES','ANIMALCOMMENTS','WEBSITEMEDIANOTES','DESCRIPTION','ANIMALDESCRIPTION','ACTIVEMOVEMENTDATE','MOSTRECENTADOPTIONDATE','ADOPTIONDATE','DATEADOPTED','MOVEMENTDATE'],
      ],
      'reports' => [
        'required' => ['A JSON array result for each report row, or an object containing an items array'],
        'supported' => ['title query parameter is passed through by the suite proxy'],
      ],
      'image' => [
        'required' => ['Binary image response or a direct proxied image URL target'],
        'supported' => ['animalid or id query parameter for lookup'],
      ],
    ];
  }

  private static function data_source_status($settings) {
    $defs = self::data_source_definitions();
    $key = sanitize_key($settings['global']['data_source'] ?? 'asm');
    if (!isset($defs[$key])) $key = 'asm';
    $def = $defs[$key];
    $missing = [];
    if ($key === 'asm') {
      if (empty($settings['proxy']['account'])) $missing[] = 'ASM account';
      if (empty($settings['proxy']['username'])) $missing[] = 'ASM username';
      if (empty($settings['proxy']['password'])) $missing[] = 'ASM password';
    } elseif ($key === 'custom_api') {
      if (empty($settings['global']['custom_api_adoptables_url']) && empty($settings['global']['custom_api_url'])) $missing[] = 'Custom API adoptables URL';
      if (empty($settings['global']['custom_api_adoptions_url']) && empty($settings['global']['custom_api_url'])) $missing[] = 'Custom API adoptions URL';
    } elseif ($key === 'shelterluv') {
      if (empty($settings['global']['shelterluv_api_key'])) $missing[] = 'Shelterluv API key';
      if (empty($settings['global']['shelterluv_org_id'])) $missing[] = 'Shelterluv organisation ID';
    } elseif ($key === 'petpoint') {
      if (empty($settings['global']['petpoint_username'])) $missing[] = 'PetPoint username';
      if (empty($settings['global']['petpoint_password'])) $missing[] = 'PetPoint password';
      if (empty($settings['global']['petpoint_shelter_id'])) $missing[] = 'PetPoint shelter ID';
    }
    $state_labels = ['live' => 'Live now', 'ready' => 'Ready for feed', 'groundwork' => 'Groundwork ready'];
    return [
      'key' => $key,
      'label' => $def['label'],
      'state' => $def['state'],
      'state_label' => $state_labels[$def['state']] ?? ucfirst($def['state']),
      'configured' => empty($missing),
      'configured_label' => empty($missing) ? 'Configured' : 'Needs details',
      'missing' => $missing,
    ];
  }

  private static function render_data_source_fields($settings, $context = 'settings') {
    $global = $settings['global'] ?? [];
    $proxy = $settings['proxy'] ?? [];
    echo '<div class="ss-source-fields">';

    echo '<div data-source-fields="asm">';
    echo '<table class="form-table">';
    self::row('ASM account', '<input type="text" name="suite[proxy][account]" value="' . esc_attr($proxy['account'] ?? '') . '" class="regular-text" />');
    self::row('ASM username', '<input type="text" name="suite[proxy][username]" value="' . esc_attr($proxy['username'] ?? '') . '" class="regular-text" autocomplete="off" />');
    self::row('ASM password', '<input type="password" name="suite[proxy][password]" value="' . esc_attr($proxy['password'] ?? '') . '" class="regular-text" autocomplete="new-password" />');
    echo '</table></div>';

    echo '<div data-source-fields="shelterluv">';
    echo '<table class="form-table">';
    self::row('Shelterluv base URL', '<input type="url" name="suite[global][shelterluv_base_url]" value="' . esc_attr($global['shelterluv_base_url'] ?? 'https://www.shelterluv.com') . '" class="regular-text code" placeholder="https://www.shelterluv.com" />');
    self::row('Shelterluv organisation ID', '<input type="text" name="suite[global][shelterluv_org_id]" value="' . esc_attr($global['shelterluv_org_id'] ?? '') . '" class="regular-text" /><p class="description">Groundwork only at present. This prepares the organisation scope for a later live connector.</p>');
    self::row('Shelterluv API key', '<input type="password" name="suite[global][shelterluv_api_key]" value="' . esc_attr($global['shelterluv_api_key'] ?? '') . '" class="regular-text" autocomplete="new-password" />');
    self::row('Animal type', '<select name="suite[global][shelterluv_animal_type]"><option value="cat" ' . selected(($global['shelterluv_animal_type'] ?? 'cat'),'cat',false) . '>cat</option><option value="cats" ' . selected(($global['shelterluv_animal_type'] ?? 'cat'),'cats',false) . '>cats</option><option value="feline" ' . selected(($global['shelterluv_animal_type'] ?? 'cat'),'feline',false) . '>feline</option><option value="any" ' . selected(($global['shelterluv_animal_type'] ?? 'cat'),'any',false) . '>any</option></select>');
    self::row('Statuses to include', '<textarea name="suite[global][shelterluv_statuses]" rows="3" class="large-text code">' . esc_textarea($global['shelterluv_statuses'] ?? 'adoptable,foster') . '</textarea><p class="description">Comma or line separated. Example: adoptable, foster</p>');
    self::row('Location IDs', '<textarea name="suite[global][shelterluv_location_ids]" rows="3" class="large-text code">' . esc_textarea($global['shelterluv_location_ids'] ?? '') . '</textarea><p class="description">Optional comma or line separated list to prepare location filtering.</p>');
    echo '</table></div>';

    echo '<div data-source-fields="petpoint">';
    echo '<table class="form-table">';
    self::row('PetPoint base URL', '<input type="url" name="suite[global][petpoint_base_url]" value="' . esc_attr($global['petpoint_base_url'] ?? '') . '" class="regular-text code" placeholder="https://ws.petango.com/webservices/adoptablesearch" />');
    self::row('PetPoint shelter ID', '<input type="text" name="suite[global][petpoint_shelter_id]" value="' . esc_attr($global['petpoint_shelter_id'] ?? '') . '" class="regular-text" /><p class="description">Groundwork only at present. This prepares the shelter or database scope for a later live connector.</p>');
    self::row('PetPoint username', '<input type="text" name="suite[global][petpoint_username]" value="' . esc_attr($global['petpoint_username'] ?? '') . '" class="regular-text" />');
    self::row('PetPoint password', '<input type="password" name="suite[global][petpoint_password]" value="' . esc_attr($global['petpoint_password'] ?? '') . '" class="regular-text" autocomplete="new-password" />');
    self::row('PetPoint species ID', '<input type="text" name="suite[global][petpoint_species_id]" value="' . esc_attr($global['petpoint_species_id'] ?? '2') . '" class="regular-text code" /><p class="description">Cat is commonly 2. Use comma separated values if your feed needs more than one.</p>');
    self::row('Statuses to include', '<textarea name="suite[global][petpoint_statuses]" rows="3" class="large-text code">' . esc_textarea($global['petpoint_statuses'] ?? 'available,foster') . '</textarea>');
    self::row('Location IDs', '<textarea name="suite[global][petpoint_location_ids]" rows="3" class="large-text code">' . esc_textarea($global['petpoint_location_ids'] ?? '') . '</textarea>');
    self::row('Adopted report ID', '<input type="text" name="suite[global][petpoint_adopted_report_id]" value="' . esc_attr($global['petpoint_adopted_report_id'] ?? '') . '" class="regular-text code" /><p class="description">Optional groundwork field for a future adopted history/report route.</p>');
    echo '</table></div>';

    echo '<div data-source-fields="custom_api">';
    echo '<table class="form-table">';
    self::row('Custom API base URL', '<input type="url" name="suite[global][custom_api_url]" value="' . esc_attr($global['custom_api_url'] ?? '') . '" class="regular-text code" placeholder="https://example.org/api" /><p class="description">Optional base URL. If the endpoint fields below are blank the suite will derive /adoptables, /adoptions, /report, /in-care-count and /animal-image from this base.</p>');
    self::row('Adoptables endpoint', '<input type="url" name="suite[global][custom_api_adoptables_url]" value="' . esc_attr($global['custom_api_adoptables_url'] ?? '') . '" class="regular-text code" placeholder="https://example.org/api/adoptables" />');
    self::row('Adoptions endpoint', '<input type="url" name="suite[global][custom_api_adoptions_url]" value="' . esc_attr($global['custom_api_adoptions_url'] ?? '') . '" class="regular-text code" placeholder="https://example.org/api/adoptions" />');
    self::row('Report endpoint', '<input type="url" name="suite[global][custom_api_report_url]" value="' . esc_attr($global['custom_api_report_url'] ?? '') . '" class="regular-text code" placeholder="https://example.org/api/report" />');
    self::row('In-care endpoint', '<input type="url" name="suite[global][custom_api_incare_url]" value="' . esc_attr($global['custom_api_incare_url'] ?? '') . '" class="regular-text code" placeholder="https://example.org/api/in-care-count" />');
    self::row('Image endpoint', '<input type="url" name="suite[global][custom_api_image_url]" value="' . esc_attr($global['custom_api_image_url'] ?? '') . '" class="regular-text code" placeholder="https://example.org/api/animal-image" />');
    self::row('Auth header', '<input type="text" name="suite[global][custom_api_auth_header]" value="' . esc_attr($global['custom_api_auth_header'] ?? 'X-API-Key') . '" class="regular-text" />');
    self::row('Custom API key', '<input type="password" name="suite[global][custom_api_key]" value="' . esc_attr($global['custom_api_key'] ?? '') . '" class="regular-text" autocomplete="new-password" /><p class="description">The suite sends the key in the header above and also as api_key for feeds that prefer a query parameter.</p>');
    echo '</table></div>';

    echo '</div>';
  }

  public static function render_setup_wizard() {
    if (!current_user_can('manage_options')) return;
    $settings = self::get_settings();
    $source_defs = self::data_source_definitions();
    $source_status = self::data_source_status($settings);
    echo '<div class="wrap"><h1>ASM Plugin Suite setup wizard</h1><p>Follow the steps below to configure your ASM connection and enable your core suite features.</p>';
    echo '<style>.ss-wizard-progress{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin:18px 0 20px}.ss-wizard-progress .ss-step{border:1px solid #d8d8e2;border-radius:16px;padding:14px;background:#fff}.ss-wizard-progress .ss-step strong{display:block;margin-bottom:4px}.ss-source-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px}.ss-source-card{position:relative;border:1px solid #d8d8e2;border-radius:18px;padding:16px;background:#fff;cursor:pointer}.ss-source-card.active{border-color:#401268;box-shadow:0 0 0 2px rgba(64,18,104,.08)}.ss-source-card input{position:absolute;opacity:0;pointer-events:none}.ss-source-chip{display:inline-block;padding:3px 8px;border-radius:999px;background:#f3edf8;font-size:12px;font-weight:600;margin-bottom:8px}.ss-source-fields [data-source-fields]{display:none}.ss-source-fields [data-source-fields].active{display:block}.ss-setup-actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.ss-checklist{margin:0;padding-left:18px}</style>';
    echo '<div class="ss-suite-panel" style="max-width:1040px;">';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
    wp_nonce_field('straysafe_ui_suite_setup_save');
    echo '<input type="hidden" name="action" value="straysafe_ui_suite_setup_save" />';
    echo '<div class="ss-wizard-progress">';
    foreach ([1=>['ASM connection','Confirm the live data source'],2=>['Connection','Save your ASM credentials'],3=>['Style','Set your default look'],4=>['Features','Turn core tools on']] as $step=>$meta) {
      echo '<div class="ss-step"><strong>Step ' . (int)$step . '</strong>' . esc_html($meta[0]) . '<br><span class="description">' . esc_html($meta[1]) . '</span></div>';
    }
    echo '</div>';
    echo '<div class="ss-suite-subnav">';
    foreach ([1=>'Step 1 · ASM connection',2=>'Step 2 · Connection',3=>'Step 3 · Style',4=>'Step 4 · Features'] as $step=>$label) echo '<button type="button" class="button ss-wizard-step-btn" data-step="'.(int)$step.'">'.esc_html($label).'</button> ';
    echo '</div>';

    echo '<div class="ss-suite-subsection active" data-step="1"><h2>Step 1 · ASM connection</h2><p class="description">This quick setup configures the native ASM connection. Custom API is also available as a live source from the Global tab after setup.</p><div class="ss-source-grid">';
    echo '<label class="ss-source-card active" data-source-card="asm">';
    echo '<input type="radio" name="suite[global][data_source]" value="asm" checked="checked" />';
    echo '<span class="ss-source-chip">Live now</span>';
    echo '<strong>Animal Shelter Manager (ASM)</strong><p>The native ASM connector is active and uses the proxy credentials saved in this wizard.</p>';
    echo '</label>';
    echo '</div></div>';

    $proxy_settings = self::get_proxy_settings($settings);
    echo '<div class="ss-suite-subsection" data-step="2"><h2>Step 2 · Connection details</h2><p class="description">Enter your ASM connection details below.</p>';
    echo '<table class="form-table">';
    ob_start(); self::text_input('proxy','base_url',$proxy_settings['base_url']); self::row('ASM base URL', ob_get_clean());
    ob_start(); self::text_input('proxy','account',$proxy_settings['account']); self::row('ASM account', ob_get_clean());
    ob_start(); self::text_input('proxy','username',$proxy_settings['username']); self::row('ASM username', ob_get_clean());
    printf('<tr><th>ASM password</th><td><input type="password" name="%s" value="%s" class="regular-text" autocomplete="new-password" /></td></tr>', esc_attr(self::field_name('proxy','password')), esc_attr($proxy_settings['password']));
    echo '</table></div>';

    echo '<div class="ss-suite-subsection" data-step="3"><h2>Step 3 · Style</h2><table class="form-table">';
    self::row('Theme preset', '<select name="suite[global][preset_name]"><option value="straysafe_default">StraySafe Default</option><option value="classic">Classic</option><option value="modern">Modern</option><option value="minimal">Minimal</option></select>');
    self::row('Accent colour', '<input type="color" name="suite[global][brand_color]" value="' . esc_attr($settings['adoptables']['brand_color'] ?? '#401268') . '" />');
    echo '</table><div class="ss-suite-note"><strong>Tip</strong><br>This step only sets the starting point. Per-module styling remains available later in the main suite tabs.</div></div>';

    echo '<div class="ss-suite-subsection" data-step="4"><h2>Step 4 · Features</h2><table class="form-table">';
    echo '<tr><th>Enable adoptables filters</th><td><label><input type="checkbox" name="suite[adoptables][enable_filters]" value="1" ' . checked(!empty($settings['adoptables']['enable_filters']), true, false) . ' /> Enable filters</label></td></tr>';
    echo '<tr><th>Enable favourites</th><td><label><input type="checkbox" name="suite[adoptables][enable_favourites]" value="1" ' . checked(!empty($settings['adoptables']['enable_favourites']), true, false) . ' /> Enable favourites</label></td></tr>';
    echo '<tr><th>Enable adopted modals</th><td><label><input type="checkbox" name="suite[adopted][enable_modals]" value="1" ' . checked(!empty($settings['adopted']['enable_modals']), true, false) . ' /> Enable adopted modals</label></td></tr>';
    echo '<tr><th>Enable match quiz</th><td><label><input type="checkbox" name="suite[quiz][quiz_enabled]" value="1" ' . checked(!empty($settings['quiz']['quiz_enabled']), true, false) . ' /> Enable quiz</label></td></tr>';
    echo '</table><h3>Before you finish</h3><ul class="ss-checklist"><li>Chosen source: <strong>' . esc_html($source_status['label']) . '</strong></li><li>Connector state: ' . esc_html($source_status['state_label']) . '</li><li>Configuration status: ' . esc_html($source_status['configured_label']) . '</li>';
    if (!empty($source_status['missing'])) echo '<li>Still missing: ' . esc_html(implode(', ', $source_status['missing'])) . '</li>';
    echo '<li>Core shortcodes and module settings remain available in the main suite pages after setup.</li></ul></div>';

    echo '<p class="ss-setup-actions">';
    submit_button('Save and finish','primary','submit',false);
    echo ' <a class="button" href="' . esc_url(add_query_arg(['page'=>'straysafe-ui-suite'], admin_url('options-general.php'))) . '">Skip for now</a>';
    echo '</p></form></div>';
    echo '<script>(function(){function currentSource(){const checked=document.querySelector("input[name=\"suite[global][data_source]\"]:checked");return checked?checked.value:"asm";}function syncSourceUi(){const source=currentSource();document.querySelectorAll("[data-source-fields]").forEach(function(el){el.classList.toggle("active",el.getAttribute("data-source-fields")===source);});document.querySelectorAll("[data-source-card]").forEach(function(el){el.classList.toggle("active",el.getAttribute("data-source-card")===source);});}document.addEventListener("click",function(e){const btn=e.target.closest(".ss-wizard-step-btn");if(btn){e.preventDefault();const step=btn.getAttribute("data-step");document.querySelectorAll(".ss-suite-subsection[data-step]").forEach(function(el){el.classList.toggle("active",el.getAttribute("data-step")===step);});}const card=e.target.closest("[data-source-card]");if(card){const input=card.querySelector("input[type=radio]");if(input){input.checked=true;syncSourceUi();}}});document.addEventListener("change",function(e){if(e.target&&e.target.name==="suite[global][data_source]")syncSourceUi();});syncSourceUi();})();</script>';
    echo '</div>';
  }

  private static function render_proxy_tab($settings) {
    $proxy = self::get_proxy_settings($settings);
    $status = self::proxy_status();
    self::form_start('proxy');
    echo '<div class="ss-suite-grid">';
    echo '<div class="ss-suite-card"><h2>Connection</h2><table class="form-table">';
    ob_start(); self::text_input('proxy','base_url',$proxy['base_url']); self::row('ASM base URL', ob_get_clean());
    ob_start(); self::text_input('proxy','account',$proxy['account']); self::row('ASM account', ob_get_clean());
    ob_start(); self::text_input('proxy','username',$proxy['username']); self::row('ASM username', ob_get_clean());
    printf('<tr><th>ASM password</th><td><input type="password" name="%s" value="%s" class="regular-text" autocomplete="new-password" /></td></tr>', esc_attr(self::field_name('proxy','password')), esc_attr($proxy['password']));
    echo '</table></div>';
    echo '<div class="ss-suite-card"><h2>Cache</h2><table class="form-table">';
    foreach ([['cache_adoptables_seconds','Adoptables cache seconds'],['cache_reports_seconds','Reports cache seconds'],['cache_incare_seconds','In-care cache seconds'],['cache_adoptions_seconds','Adoptions cache seconds']] as $row) { ob_start(); self::number_input('proxy',$row[0],$proxy[$row[0]],0,3600); self::row($row[1], ob_get_clean()); }
    echo '</table></div>';
    echo '<div class="ss-suite-card"><h2>Diagnostics</h2><table class="form-table">';
    self::row('Credential source', '<code>' . esc_html($status['credential_source']) . '</code>');
    self::row('Selected data source', esc_html($status['data_source']['label'] ?? 'Animal Shelter Manager (ASM)'));
    self::row('Connector state', esc_html($status['data_source']['state_label'] ?? 'Live'));
    self::row('Configuration', esc_html($status['data_source']['configured_label'] ?? 'Managed in this suite'));
    if (!empty($status['data_source']['missing'])) self::row('Missing details', esc_html(implode(', ', $status['data_source']['missing'])));
    self::row('Last successful test', esc_html($status['last_success'] ?: 'None yet'));
    self::row('Last error', esc_html($status['last_error'] ?: 'None'));
    self::row('REST routes', '<code>' . esc_html(implode(' | ', $status['routes'])) . '</code>');
    echo '</table></div>';
    echo '</div>';
    self::form_end();

    // Tool actions must not be nested inside the main settings form. Nested forms
    // cause browsers to close the settings form early, which prevents proxy
    // credentials from being submitted with the Save changes button.
    echo '<div class="ss-suite-grid" style="margin-top:16px;">';
    echo '<div class="ss-suite-card" style="grid-column:1/-1;"><h2>Tools</h2><div class="ss-suite-actions">';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">'; wp_nonce_field('straysafe_ui_suite_proxy_test'); echo '<input type="hidden" name="action" value="straysafe_ui_suite_proxy_test" />'; submit_button('Test connection','secondary','submit',false); echo '</form>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">'; wp_nonce_field('straysafe_ui_suite_proxy_clear_cache'); echo '<input type="hidden" name="action" value="straysafe_ui_suite_proxy_clear_cache" />'; submit_button('Clear proxy cache','secondary','submit',false); echo '</form>';
    echo '<a class="button" href="' . esc_url(add_query_arg(['page'=>'straysafe-ui-suite-setup'], admin_url('options-general.php'))) . '">Open setup wizard</a>';
    echo '</div></div></div>';
  }

  private static function render_diagnostics_tab($settings) {
    $log = get_option(self::LOG_KEY, []); if (!is_array($log)) $log = [];
    $snapshots = self::get_snapshots();
    $versions = self::module_versions();
    $status = self::proxy_status();
    $analytics = self::get_analytics();
    $sub = self::subtab_nav('diagnostics', ['overview'=>'Overview','sources'=>'Source contracts','versions'=>'Version log','snapshots'=>'Snapshots','modules'=>'Module import/export']);
    echo '<div class="ss-suite-grid">';
    if($sub==='overview') {
      echo '<div class="ss-suite-card"><h2>Versions</h2><table class="ss-suite-table"><tbody>';
      foreach ($versions as $k => $v) echo '<tr><th>' . esc_html(ucwords(str_replace('_',' ',$k))) . '</th><td><code>' . esc_html($v) . '</code></td></tr>';
      echo '<tr><th>Settings option key</th><td><code>' . esc_html(self::OPT_KEY) . '</code></td></tr>';
      echo '</tbody></table></div>';
      echo '<div class="ss-suite-card"><h2>Proxy health</h2><table class="ss-suite-table"><tbody>';
      foreach (['credential_source' => 'Credential source', 'last_success' => 'Last successful test', 'last_error' => 'Last error'] as $key => $label) echo '<tr><th>' . esc_html($label) . '</th><td>' . esc_html($status[$key] ?: 'None') . '</td></tr>';
      echo '<tr><th>Data source</th><td>' . esc_html($status['data_source']['label'] ?? 'Unknown') . '</td></tr>';
      echo '<tr><th>Connector state</th><td>' . esc_html($status['data_source']['state_label'] ?? 'Unknown') . '</td></tr>';
      echo '<tr><th>Configuration</th><td>' . esc_html($status['data_source']['configured_label'] ?? 'Unknown') . '</td></tr>';
      if (!empty($status['data_source']['missing'])) echo '<tr><th>Missing details</th><td>' . esc_html(implode(', ', $status['data_source']['missing'])) . '</td></tr>';
      echo '</tbody></table></div>';
      echo '<div class="ss-suite-card"><h2>Analytics</h2><table class="ss-suite-table"><tbody>';
      foreach ($analytics as $key => $count) echo '<tr><th>' . esc_html(ucwords(str_replace('_',' ',$key))) . '</th><td>' . esc_html((string)$count) . '</td></tr>';
      echo '</tbody></table></div>';

    } elseif($sub==='sources') {
      $runtime = self::source_runtime_config($settings);
      $ref = self::source_contract_reference();
      echo '<div class="ss-suite-card"><h2>Selected source runtime</h2><table class="ss-suite-table"><tbody>';
      foreach (($runtime['items'] ?? []) as $label => $value) echo '<tr><th>' . esc_html($label) . '</th><td><code>' . esc_html(((string)$value !== '' ? (string)$value : 'Not set')) . '</code></td></tr>';
      echo '</tbody></table><p class="description">' . esc_html($runtime['contract'] ?? '') . '</p></div>';
      echo '<div class="ss-suite-card" style="grid-column:1/-1;"><h2>Normalised source contract reference</h2><p class="description">These are the suite-standard fields the groundwork is preparing each connector to resolve into. Custom API can already feed these live.</p>';
      foreach ($ref as $section => $meta) {
        echo '<h3>' . esc_html(ucfirst($section)) . '</h3>';
        echo '<p><strong>Required:</strong> <code>' . esc_html(implode(', ', (array)($meta['required'] ?? []))) . '</code></p>';
        echo '<p><strong>Supported:</strong> <code>' . esc_html(implode(', ', (array)($meta['supported'] ?? []))) . '</code></p>';
      }
      echo '<p class="description">Example Custom API adoptables item: <code>{ID, ANIMALNAME, CODE, ANIMALAGE, AGE_MONTHS, AGE_BAND, SEXNAME, BREEDNAME, SPECIESID, SPECIESNAME, WEBSITEIMAGECOUNT, ANIMALCOMMENTS}</code></p></div>';
    } elseif($sub==='versions') {
      echo '<div class="ss-suite-card" style="grid-column:1/-1;"><h2>Version log</h2>';
      if (!$log) echo '<p>No version events logged yet.</p>';
      else { echo '<table class="ss-suite-table"><thead><tr><th>Time</th><th>Event</th><th>Suite</th></tr></thead><tbody>'; foreach ($log as $entry) echo '<tr><td>' . esc_html($entry['time'] ?? '') . '</td><td><code>' . esc_html($entry['event'] ?? '') . '</code></td><td>' . esc_html($entry['suite_version'] ?? '') . '</td></tr>'; echo '</tbody></table>'; }
      echo '</div>';
    } elseif($sub==='snapshots') {
      echo '<div class="ss-suite-card" style="grid-column:1/-1;"><h2>Settings snapshots</h2>';
      if (!$snapshots) { echo '<p>No snapshots yet. A snapshot is created before reset, import, module import and save.</p>'; }
      else {
        echo '<table class="ss-suite-table"><thead><tr><th>Time</th><th>Reason</th><th>ID</th><th>Actions</th></tr></thead><tbody>';
        foreach ($snapshots as $snapshot) {
          echo '<tr><td>' . esc_html($snapshot['time'] ?? '') . '</td><td><code>' . esc_html($snapshot['reason'] ?? '') . '</code></td><td><code>' . esc_html(substr($snapshot['id'] ?? '', 0, 8)) . '</code></td><td><div class="ss-suite-actions">';
          echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">'; wp_nonce_field('straysafe_ui_suite_restore_snapshot'); echo '<input type="hidden" name="action" value="straysafe_ui_suite_restore_snapshot" /><input type="hidden" name="snapshot_id" value="' . esc_attr($snapshot['id'] ?? '') . '" />'; submit_button('Restore','secondary','submit',false); echo '</form>';
          echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">'; wp_nonce_field('straysafe_ui_suite_delete_snapshot'); echo '<input type="hidden" name="action" value="straysafe_ui_suite_delete_snapshot" /><input type="hidden" name="snapshot_id" value="' . esc_attr($snapshot['id'] ?? '') . '" />'; submit_button('Delete','secondary','submit',false); echo '</form>';
          echo '</div></td></tr>';
        }
        echo '</tbody></table>';
      }
      echo '</div>';
    } else {
      echo '<div class="ss-suite-card" style="grid-column:1/-1;"><h2>Module export / import</h2><div class="ss-suite-actions">';
      foreach (['adoptables','adopted','stats','forms','proxy'] as $module) {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">'; wp_nonce_field('straysafe_ui_suite_export_module'); echo '<input type="hidden" name="action" value="straysafe_ui_suite_export_module" /><input type="hidden" name="module" value="' . esc_attr($module) . '" />'; submit_button('Export ' . ucfirst($module),'secondary','submit',false); echo '</form>';
      }
      echo '</div><div class="ss-suite-actions" style="margin-top:12px;">';
      foreach (['adoptables','adopted','stats','forms','proxy'] as $module) {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" enctype="multipart/form-data">'; wp_nonce_field('straysafe_ui_suite_import_module'); echo '<input type="hidden" name="action" value="straysafe_ui_suite_import_module" /><input type="hidden" name="module" value="' . esc_attr($module) . '" /><label>' . esc_html(ucfirst($module)) . ' import <input type="file" name="import_file" accept="application/json" /></label> '; submit_button('Import','secondary','submit',false); echo '</form>';
      }
      echo '</div></div>';
    }
    echo '</div>';
  }

}
